<?php



#p'agina para cerrar la sesi'on.
#iniciamos la sesi'on
session_start();

#destruimos las variables de sesi'on
session_destroy();

#eliminamos la cookie
setcookie("loginOk", "", time()-63072001);

require 'includes/conexion.inc.php';
#cerramos la conexi'on con la base de datos
mysqli_close($conectar);

#llevamos al usuario a index.html
header('Location: index.php');


///Log///

?>