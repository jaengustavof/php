<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<meta name="author" content="JuanK">
	<meta name="copyright" content="">
	<meta name="contact" content="">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="robots" content="NoIndex, NoFollow">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, shrink-to-fit=no">

	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">

		<!-- Fonts -->
		<link href="https://fonts.googleapis.com/css2?family=Lobster&display=swap" rel="stylesheet">

		<link href="https://fonts.googleapis.com/css2?family=Lobster&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

		<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">


	<link rel="icon" type="icon/png" href="fav.png">
	<title>Pegatinas | Gestor de Proyectos</title>
</head>
<body>

	<nav class="menuInicio">
		<div class="logo">Pegatinas</div>

		<div>
			<a class="enlaceIndex enlaceIzq" href="login.php">Log in</a><a class="enlaceIndex" href="admin/index.php">Admin</a>
		</div>
		
		
	</nav>
	<header>
		<div class="contenedorHeader">
			<h1>Gestiona tus proyectos de forma ágil y sin esfuerzo.</h1>
			<div class="contenidoHeader">
				<div class="botonYtexto">
					<p>Pegatinas 
						es un gestior de proyectos colaborativo que agiliza y refina su flujo de trabajo existente. Administrar sus tareas no debería ser un trabajo complicado.
					</p>
					<div class="botonHeader">
						<a href="login.php"><button>Entrar</button></a>
					</div>
					
					
				</div>
				<div class="fotoHeader">
					<img src="https://jaenwebdesign.com/PHP/Proyecto/assets/rsc/img/IMGHero.png" alt="persona trabajando con su ordenador">
					
				</div>
			</div>
			
			
		</div>
	</header>

	<div class="features">
		<div class="contenedorFeature">
			<div class="feature">
				<img src="https://jaenwebdesign.com/PHP/Proyecto/assets/rsc/img/zoom-in-out-svg.png" alt="icono visualiza">
				<h3>Visualiza</h3>
				<p>Observa el progreso de tus equipos en un sólo módulo.</p>
			</div>
			<div class="feature">
				<img src="https://jaenwebdesign.com/PHP/Proyecto/assets/rsc/img/colabora-svg.png" alt="icono colabora">
				<h3>Colabora</h3>
				<p>Establezca sus prioridades y programe sus objetivos.</p>
			</div>
			<div class="feature">
				<img src="https://jaenwebdesign.com/PHP/Proyecto/assets/rsc/img/interactivo-svg.png" alt="icono interactua">
				<h3>Interactúa</h3>
				<p>Interfaz de usuario fácil de arrastrar y soltar.</p>
			</div>
			<div class="feature">
				<img src="https://jaenwebdesign.com/PHP/Proyecto/assets/rsc/img/clock-time-3-svg%20(1).png" alt="icono analiza">
				<h3>Analiza</h3>
				<p>Analiza y gestiona el rendimiento de tu equipo.</p>
			</div>		
		</div>
		
	</div>

	<div class="comentario">
		<div class="contenidoComentario">
			<div class="comentarioTexto">
				<p>“ Pegatinas proporciona la capacidad de trabajar en una lista de tareas donde puedo marcar las acciones pendientes, hasta el final para rastrear la velocidad de trabajo de toda mi empresa. “ </p>
				<p class="firmaComentario">Victor Sotelo Nuñez - CEO Marenga Corp.</p>
			</div>
			<div class="comentarioFoto">
				<img src="https://jaenwebdesign.com/PHP/Proyecto/assets/rsc/img/comentario.png" alt="Foto CEO Marenga Corp">
			</div>
		</div>
	</div>

	<footer>
		<div class="datosFooter">
			<p>© Pegatinas S.A | All  Rights Reserved. CIF 789456123C</p>
		</div>
		<div class="socialFooter">
			<img src="https://jaenwebdesign.com/PHP/Proyecto/assets/rsc/img/facebook-square-brands-svg.png" alt="Icono facebook">
			<img src="https://jaenwebdesign.com/PHP/Proyecto/assets/rsc/img/instagram-square-brands-svg.png" alt="Icono Instagram">
			<img src="https://jaenwebdesign.com/PHP/Proyecto/assets/rsc/img/linkedin-brands-svg.png" alt="Icono LinkedIn">
			<img src="https://jaenwebdesign.com/PHP/Proyecto/assets/rsc/img/twitter-square-brands-svg.png" alt="Icono Twitter">
		</div>
	</footer>

	
	
</body>
</html>