<?php
///Si ya existe una cookie lo enviamos directamente a main.php///
if(isset($_COOKIE['loginOk'])){
   header('Location: main.php');

    
}
////Verificamos si se envian datos por el formulario de Login/////

/////LOGIN/////
if ($_POST) {
    //Se controla que todos los campos existan y no estén vacios///
        if (isset($_POST['correo']) && isset($_POST['clave'])) {
            if (!empty($_POST['correo']) && !empty($_POST['clave'])) {
                $correo = $_POST['correo'];
                $clave = $_POST['clave'];

                require 'includes/conexion.inc.php';
                #realizamos una consulta para comprobar si el correo existe y la cuenta esté activa
                $sqlLogin = "
                    SELECT *
                        FROM usuario
                        WHERE correo_usuario LIKE '".$correo."'
                            AND activo_usuario LIKE 1;

                ";
                $queryLogin = mysqli_query($conectar, $sqlLogin);
                if (mysqli_num_rows($queryLogin) == 0) {
                    //si la cuenta no está activa se devuelve un mensaje de error//
                    echo '<div class="alert alert-danger" role="alert">Debes activar tu cuenta. Contacta con el administrador</div>';

                }else{

                    while($rowLogin = mysqli_fetch_assoc($queryLogin)){
                        #verificamos que la clave ingresada y la clave registrada sean iguales
                        if(password_verify($clave, $rowLogin['clave_usuario'])){
                            //echo "Bienvenido!";
                            if($rowLogin['validado_usuario'] == 1) {
                            #Si el usuario esta validado.
                            
                                session_start();

                                #guardamos los datos del usuario que variables de sesion
                                $_SESSION['idUsu'] = $rowLogin['id_usuario'];
                                $_SESSION['nombreUsu'] = $rowLogin['nombre_usuario'];
                                $_SESSION['apellidoUsu'] = $rowLogin['apellido_usuario'];
                                $_SESSION['correoUsu'] = $rowLogin['correo_usuario'];
                                $_SESSION['telefonoUsu'] = $rowLogin['telefono_usuario'];
                                $_SESSION['fdnUsu'] = $rowLogin['fdn_usuario'];
                                $_SESSION['areaUsu'] = $rowLogin['id_area'];
                                $_SESSION['rolUsu'] = $rowLogin['id_rol'];
                                $_SESSION['estadoUsu'] = $rowLogin['id_estado'];

                                //Creamos una cookie en caso que el usuario haya seleccionado la opción de ¨recuerdame¨//
                                if(isset($_POST['recuerda'])){
                                    setcookie("loginOk", $_SESSION['correoUsu'], time()+63072000);
                                }

                                #enviamos a main.php si las credenciales son correctas
                                header('Location: main.php');

                               
                            
                            }else{
                                #Si no está validado
                                echo '<div class="alert alert-danger" role="alert">Debes validar tu cuenta antes de ingresar</div>';
                            }
                            
                        }else{
                            //Si el usuario o la contraseña son incorrectos
                            echo '<div class="alert alert-danger" role="alert">Usuario y o Contraseña INCORRECTO</div>';
                            
                        }
                    }
                }




            }else{
                //si los formularios vienen vacios
            echo '<div class="alert alert-danger" role="alert">Debes rellenar todos los campos</div>';
            }

        }else{
            //si intenta eliminar alguno de los campos del formulario
        echo '<div class="alert alert-danger" role="alert">Debes introducir los datos</div>';
        }

}
////Fin if Login////

?>


<!DOCTYPE html>
<html lang="es">
<head>
     <!--META-->
        <meta charset="UTF-8"> 
        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!--retrocompatible con microsoft edge-->
        <meta name="author" content=""><!-- quien hace la pagina web / desarrollador -->
        <meta name="copyright" content=""><!--derecho de copyright / derechos de explotacion / es a empresa-->
        <meta name="contact" content=""> <!--se especifica correo electronico de la persona que lleva el mantenimiento del sitio-->
        <meta name="description" content=""> <!--descripcion de la pagina web-->
        <meta name="keywords" content=""> <!--palabras clave por las que se indexan-->
        <meta name="robots" content="NoIndex, NoFollow"> <!--sustituye al robots.txt / el dia que se indexe cambia el content-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, shrink-to-fit=no">  
        <!--FontAwesome-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/bootadmin.min.css">

    <link rel="icon" type="icon/png" href="fav.png">
    

    <title>Pegatinas | Login Usuario</title>
</head>
<body class="bg-dark" cz-shortcut-listen="true">

        <div class="container h-100">
        <div class="row h-100 justify-content-center align-items-center">
            <div class="col-md-4">
                <h1 class="text-center mb-4 text-white">Pegatinas Login Usuario</h1>
                <div class="card">
                    <div class="card-body">
                        <form name="formuLogin" action="" method="POST" >
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fa fa-user"></i></span>
                                </div>
                                <input type="email" value="" class="form-control" name="correo" placeholder="Email" required>
                            </div>

                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fa fa-key"></i></span>
                                </div>
                                <input type="password" value="" name="clave" class="form-control" placeholder="Contraseña" required>
                            </div>

                            <div class="form-check mb-3">
                                <label class="form-check-label">
                                    <input type="checkbox" name="recuerda" class="form-check-input">
                                    Recuérdame
                                </label>
                            </div>

                            <div class="row">
                                <div class="col pr-2">
                                    <button type="submit" class="btn btn-block btn-primary">Iniciar Sesión</button>
                                </div>
                                <div class="col pl-2">
                                    <a class="btn btn-block btn-link" href="olvidaClave.php">Olvidé mi contraseña</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/datatables.min.js"></script>
<script src="assets/js/moment.min.js"></script>
<script src="assets/js/fullcalendar.min.js"></script>
<script src="assets/js/bootadmin.min.js"></script>





</body>
</html>