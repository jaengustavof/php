<?php

///// INGRESO DE CLAVE Y VERIFICACIÓN EN BBDD/////

require 'includes/conexion.inc.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


if($_POST){


        if(isset($_POST['correo']) && !empty($_POST['correo'])){

            $correoUsuario = $_POST['correo'];
            $sqlCambiaCorreo = "  
                SELECT *
                    FROM usuario
                    WHERE correo_usuario LIKE '".$_POST['correo']."';

            ";

            $queryCambiaCorreo = mysqli_query($conectar, $sqlCambiaCorreo);

             if(mysqli_num_rows($queryCambiaCorreo) > 0) {



                require 'includes/Exception.php';
                require 'includes/PHPMailer.php';
                require 'includes/SMTP.php';

                   //Crea el objeto
               $correoElectronico = new PHPMailer;
                // Emisor
                $correoElectronico->setFrom('info@jaenwebdesign.com', 'Pegatinas');
                // Receptor
                $correoElectronico->addAddress($correoUsuario, $correoUsuario );
                // Asunto
                $correoElectronico->Subject = 'Restablecer contraseña';
               
                $correoElectronico->msgHTML('Para cambiar tu contraseña haz click <a href="https://jaenwebdesign.com/PHP/Proyecto/cambiaClave.php?correo='.$correoUsuario.'">AQUI</a>');

                // Codificación de Caracteres
                $correoElectronico->CharSet = 'UTF-8';

              echo '<div class="alert alert-success" role="alert">Hemos enviado un mensaje a tu dirección de correo eletrónico.</div>';

                }else{
                    echo '<div class="alert alert-danger" role="alert">La dirección de correo ingresada no existe en nuestros registros..</div>';
                }
              
 

        }

}


?>


<!DOCTYPE html>
<html lang="es">
<head>
     <!--META-->
        <meta charset="UTF-8"> 
        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!--retrocompatible con microsoft edge-->
        <meta name="author" content=""><!-- quien hace la pagina web / desarrollador -->
        <meta name="copyright" content=""><!--derecho de copyright / derechos de explotacion / es a empresa-->
        <meta name="contact" content=""> <!--se especifica correo electronico de la persona que lleva el mantenimiento del sitio-->
        <meta name="description" content=""> <!--descripcion de la pagina web-->
        <meta name="keywords" content=""> <!--palabras clave por las que se indexan-->
        <meta name="robots" content="NoIndex, NoFollow"> <!--sustituye al robots.txt / el dia que se indexe cambia el content-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, shrink-to-fit=no">  
        <!--FontAwesome-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/bootadmin.min.css">

    <link rel="icon" type="icon/png" href="fav.png">

    <title>Pegatinas | Olvida contraseña</title>
</head>
<body class="bg-dark" cz-shortcut-listen="true">

        <div class="container h-100">
        <div class="row h-100 justify-content-center align-items-center">
            <div class="col-md-4">
                <h1 class="text-center mb-4 text-white">Pegatinas Olvida Contraseña</h1>
                <p class="text-center mb-4 text-white"> Por favor, ingrese el correo electrónivo de su cuenta.</p>
                <div class="card">
                    <div class="card-body">
                        <form name="formuLogin" action="" method="POST" >
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fa fa-envelope"></i></span>
                                </div>
                                <input type="email" value="" class="form-control" name="correo" placeholder="Email" required>
                            </div>

                            <div class="row">

                                <div class="col pl-2">
                                    <a class="btn btn-block btn-link" href="login.php">Volver</a>
                                </div>
                                <div class="col pr-2">
                                    <button type="submit" class="btn btn-block btn-primary" name="compruebaEmail">Enviar</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/datatables.min.js"></script>
<script src="assets/js/moment.min.js"></script>
<script src="assets/js/fullcalendar.min.js"></script>
<script src="assets/js/bootadmin.min.js"></script>





</body>
</html>