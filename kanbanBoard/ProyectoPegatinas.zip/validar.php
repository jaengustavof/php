<?php

    if ($_GET){
        if (isset($_GET['emailReg']) && !empty($_GET['emailReg'])){
            require 'includes/conexion.inc.php';
            $sqlValidar = "
                UPDATE usuario
                    SET validado_usuario = 1
                    WHERE correo_usuario LIKE '".$_GET['emailReg']."';
            ";
            $queryValidar = mysqli_query($conectar, $sqlValidar);
            header('Location: index.php?validado');
        }else{
            header('Location: index.php');
        }
    }else{
        header('Location: index.php');
    }

?>