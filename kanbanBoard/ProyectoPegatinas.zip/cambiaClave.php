<?php


//verifica que exista el correo enviado por getallheaders()
    if ($_GET) {
        if (isset($_GET['correo']) && !empty($_GET['correo'])) {
            $correo = $_GET['correo'];
        }else{
            header('Location: index.php');
        }
    }else{
        header('Location: index.php');
    }

    if ($_POST) {
        if ((isset($_POST['nuevaClave']) && !empty($_POST['nuevaClave'])) && (isset($_POST['repiteClave']) && !empty($_POST['repiteClave']))) {
            if ($_POST['nuevaClave'] == $_POST['repiteClave']) {
                require 'includes/conexion.inc.php';
                $sqlCambiaClave = "
                    UPDATE usuario
                        SET clave_usuario = '".password_hash($_POST['nuevaClave'], PASSWORD_DEFAULT)."'
                        WHERE correo_usuario LIKE '".$correo."';
                ";
                $queryCambiaClave = mysqli_query($conectar, $sqlCambiaClave);
                if ($queryCambiaClave) {

                    echo '<div class="alert alert-success" role="alert">Contraseña modificada. Puedes acceder desde el <a href="index.php">inicio</a></div>';
                }else{
                     echo '<div class="alert alert-success" role="alert">Ha ocurrido un error inesperado. Inténtalo de nuevo más tarde.<a href="index.php">inicio</a></div>';
                }
            }else{
                echo '<div class="alert alert-success" role="alert">Los campos ingresados no coinciden.<a href="index.php">inicio</a></div>';
            }
        }
    }


?>


<!DOCTYPE html>
<html lang="es">
<head>
     <!--META-->
        <meta charset="UTF-8"> 
        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!--retrocompatible con microsoft edge-->
        <meta name="author" content=""><!-- quien hace la pagina web / desarrollador -->
        <meta name="copyright" content=""><!--derecho de copyright / derechos de explotacion / es a empresa-->
        <meta name="contact" content=""> <!--se especifica correo electronico de la persona que lleva el mantenimiento del sitio-->
        <meta name="description" content=""> <!--descripcion de la pagina web-->
        <meta name="keywords" content=""> <!--palabras clave por las que se indexan-->
        <meta name="robots" content="NoIndex, NoFollow"> <!--sustituye al robots.txt / el dia que se indexe cambia el content-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, shrink-to-fit=no">  
        <!--FontAwesome-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/bootadmin.min.css">

    
    <link rel="icon" type="icon/png" href="fav.png">
    
    <title>Pegatinas | Nueva Contraseña</title>
</head>
<body class="bg-dark" cz-shortcut-listen="true">

        <div class="container h-100">
        <div class="row h-100 justify-content-center align-items-center">
            <div class="col-md-4">
                <h1 class="text-center mb-4 text-white">Nueva Contraseña</h1>
                <p class="text-center mb-4 text-white"> Por favor, ingrese su nueva contraseña.</p>
                <div class="card">
                    <div class="card-body">
                        <form name="formuLogin" action="" method="POST" >
                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fa fa-user"></i></span>
                                </div>
                                <input type="password" value="" class="form-control" name="nuevaClave" placeholder="Nueva Contraseña" required>
                            </div>

                            <div class="input-group mb-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"><i class="fa fa-key"></i></span>
                                </div>
                                <input type="password" value="" name="repiteClave" class="form-control" placeholder="Repite Contraseña" required>
                            </div>


                            <div class="row">
                                <div class="col pr-2">
                                    <button type="submit" class="btn btn-block btn-primary">Modificar Contraseña</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/datatables.min.js"></script>
<script src="assets/js/moment.min.js"></script>
<script src="assets/js/fullcalendar.min.js"></script>
<script src="assets/js/bootadmin.min.js"></script>





</body>
</html>