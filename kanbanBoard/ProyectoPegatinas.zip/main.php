<?php

	
	session_start();

	#su no existe variable de session lo lleva al index.
	if(!isset($_SESSION['idUsu'])) {

		header('Location: index.php');
	}

	#si existe la session, iniciamos la conexión a la base de datos

	require 'includes/conexion.inc.php';


if($_POST) {

	#======================================#
	# ACTUALIZAR DATOS DEL PERFIL          #
	#======================================#
	if(isset($_POST['cambiarDatosUsuario'])){

		if(!isset($_POST['telefono'])){#es informacion opcional, si la completa se cambiar'a por la nueva. De lo contrario quedar'a la existente.

			$telefono = "";

		}else{
			$telefono = $_POST['telefono'];
		}


		if((isset($_POST['nombre']) && !empty($_POST['nombre'])) && (isset($_POST['apellido']) && !empty($_POST['apellido'])) && (isset($_POST['correo']) && !empty($_POST['correo'])) && (isset($_POST['fdn']) && !empty($_POST['fdn']))){

			#si los datos son correctos atualizamos la bbdd.

			$sqlCambiarDatosUsuario = "   

				UPDATE usuario
					SET nombre_usuario = '".$_POST['nombre']."',
                  		apellido_usuario = '".$_POST['apellido']."',
                  		correo_usuario = '".$_POST['correo']."',
                  		fdn_usuario = '".$_POST['fdn']."',
                  		telefono_usuario = '".$telefono."'
                  		WHERE id_usuario LIKE ".$_POST['identificador'].";
			";

			$queryCambiarDatosUsuario = mysqli_query($conectar, $sqlCambiarDatosUsuario);

			echo '<div class="alert alert-success" role="alert">
                Se han actualizado los datos correctamente.
            </div>';

		}
	}


	#======================================#
	# ACTUALIZAR CONTRASEÑA USUARIO        #
	#======================================#

	if(isset($_POST['cambiarClave'])){

		if((isset($_POST['contrasena']) && !empty($_POST['contrasena'])) && (isset($_POST['repiteContrasena']) && !empty($_POST['repiteContrasena'])) ) {

				#comprobamos que los campos ingresados sean iguales
        		if($_POST['contrasena'] == $_POST['repiteContrasena']) {

        			$sqlCambiarClave = " 
           			UPDATE usuario
              		SET clave_usuario = '".password_hash($_POST['contrasena'], PASSWORD_DEFAULT)."'
              		WHERE id_usuario LIKE ".$_POST['identificadorClave'].";

          			";

          			$queryCambiarClave = mysqli_query($conectar, $sqlCambiarClave);

         			echo '<div class="alert alert-success" role="alert">=Contraseña modificada correctamente.</div>';
		        }else {

		          	echo '<div class="alert alert-danger" role="alert">=Contraseña modificada correctamente.</div>';
		        }
        	}
	}

	#======================================#
	# MODIFICAR ESTADO DEL USUARIO         #
	#======================================#

	if(isset($_POST['cambiarEstadoUsuario'])){

		if((isset($_POST['estado']) && !empty($_POST['estado']))){

			$sqlCambiarEstado = "   

				UPDATE usuario
					SET id_estado = '".$_POST['estado']."'
					WHERE id_usuario LIKE '".$_SESSION['idUsu']."';

			";

			$queryCambiarEstado = mysqli_query($conectar,$sqlCambiarEstado);


		}


	}




	  #=========================================
    #CREAR TAREA
    #=========================================
    if(isset($_POST['crearNuevaTarea'])){
     
     if((isset($_POST['nombreNuevaTarea']) && !empty($_POST['nombreNuevaTarea'])) && (isset($_POST['DescripcionNuevaTarea']) && !empty($_POST['DescripcionNuevaTarea'])) && (isset($_POST['fdcNuevaTarea']) && !empty($_POST['fdcNuevaTarea'])) && (isset($_POST['fdaNuevaTarea']) && !empty($_POST['fdaNuevaTarea'])) && (isset($_POST['estadoNuevaTarea']) && !empty($_POST['estadoNuevaTarea'])) && (isset($_POST['categoriaNuevaTarea']) && !empty($_POST['categoriaNuevaTarea']))){

        $sqlCrearTarea = "  

          INSERT INTO tarea
            VALUES (null, '".$_POST['nombreNuevaTarea']."', '".$_POST['DescripcionNuevaTarea']."', '".$_POST['fdcNuevaTarea']."', '".$_POST['fdcNuevaTarea']."', '".$_POST['estadoNuevaTarea']."','".$_POST['categoriaNuevaTarea']."');

        ";

        $queryCrearTarea = mysqli_query($conectar, $sqlCrearTarea);

          echo '<div class="alert alert-success" role="alert">
                Tarea creada correctamente.
            </div>';

     }else{

          echo '<div class="alert alert-danger" role="alert">
                Todos los campos son obligatorios.
            </div>';
        }


    }








}

?>

<!DOCTYPE html>
<html lang="es">
<head>
	<!-- META -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="author" content="">
	<meta name="copyright" content="">
	<meta name="contact" content="">
	<meta name="description" content="">
	<meta name="keywords" content="">
	<meta name="robots" content="NoIndex, NoFollow">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, shrink-to-fit=no">

	<!-- ESTILOS -->
	<link rel="stylesheet" type="text/css" href="vendor/jqueryUI/css/jquery-ui.min.css">
	<link rel="stylesheet" href="assets/css/style.css">

	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/all.css">
  
    <link rel="stylesheet" href="assets/css/datatables.min.css">

    <link rel="stylesheet" href="assets/css/bootadmin.min.css">
    <link rel="stylesheet" href="assets/css/fontawesome-all.min.css">
   

   

        


	<!-- TÍTULO & LOGO -->
	<link rel="icon" type="icon/png" href="fav.png">
	<title></title>
</head>


<body>

	<!--Modal Perfil -->
<?php
                  #realizamos la consulta en la base de datos para ingresar la informacio'n de los usuarios en la tabla. Los JOIN son para poder ingresar los nombres de los IDs, los nombres de los estados de usuarios y el nombre de las 'areas en los SELECT del formulario de edici'on.
                    $sqlUsuarios = "  

                      SELECT *
                        FROM usuario
                          JOIN rol USING (id_rol)
                          JOIN estadousu USING (id_estado)
                          JOIN area USING (id_area)
                          WHERE id_usuario LIKE ".$_SESSION['idUsu'].";


                    ";

                    $queryUsuarios = mysqli_query($conectar, $sqlUsuarios);

                    while ($rowUsuarios = mysqli_fetch_assoc($queryUsuarios)){
                       
                        
                        ?> 

<nav class="navbar navbar-expand navbar-dark bg-dark navegadorMain">
    
    <a class="navbar-brand" href="main.php">Pegatinas</a>

    <div class="navbar-collapse collapse">

        <ul class="navbar-nav ml-auto">
            <a href="#" class="btn btn-icon btn-dark mr-2" data-toggle="collapse" data-target="#nuevaTarea"><i class="fas fa-plus-square"></i></a>
            <li class="nav-item dropdown">
				
                <a href="#" id="dd_user" class="nav-link dropdown-toggle " data-toggle="dropdown"><i class="fa fa-user mr-2" style="color: <?php echo $rowUsuarios['color_estado']; ?>"></i> 
                	<!--ingresamos el color del estad y el nombre de usuarios en la barra del nav-->
                	<?php echo $_SESSION['nombreUsu']?>
                </a>
                

                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dd_user">
                    <a href="#" class="dropdown-item" data-toggle="modal" data-target="#modalPerfil">Perfil</a>
                    <a href="#" class="dropdown-item" data-toggle="modal" data-target="#modalEstadoUsuario">Estado</a>

                    <a href="cerrar.php" class="dropdown-item">Cerrar Sesión</a>
                </div>
            </li>
        </ul>
    </div>

</nav>

<!--Modal Nueva Tarea-->
 <div class="collapse my-3 p-2" id="nuevaTarea" style="">
                <div class="card card-body bg-ligh">
                    <form name="formuNuevaTarea" method="POST">
                      <div class="form-row">
                          <div class="col-md-2 mb-3">
                              <label for="nombreNuevaTarea">Nombre</label>
                                  <input type="text" class="form-control" id="nombreNuevaTarea" name="nombreNuevaTarea" placeholder="Nombre" value="" required>
    
                          </div>
                          <div class="col-md-2 mb-3">
                              <label for="DescripcionNuevaTarea" readonly>Descripcion *</label>
                              <textarea class="form-control" name="DescripcionNuevaTarea" id="DescripcionNuevaTarea" rows="2" required style="height: 34px; resize: none"></textarea>
                                <br>   
                          </div>

                          <!-- Al crear una tarea, la fecha de creación y la fecha de actualización toman por defecto la fecha actual -->
                          <div class="col-md-2 mb-3">
                              <label for="fdcNuevaTarea">Fecha de Creación </label>
                                  <input type="text" class="form-control" id="fdcNuevaTarea" name="fdcNuevaTarea" placeholder="Fdc" value="<?php echo date('Y-m-d'); ?>" required readonly>
    
                          </div>
             

                      </div>
                      <div class="form-row">
                        <!-- Al crear una tarea, la fecha de creación y la fecha de actualización toman por defecto la fecha actual -->
                          <div class="col-md-2 mb-3">
                              <label for="fdaNuevaTarea">Fecha de Actualización</label>
                                  <input type="text" class="form-control" id="fdaNuevaTarea" name="fdaNuevaTarea" placeholder="Contraseña" value="<?php echo date('Y-m-d'); ?>" required readonly>
    
                          </div>

                           <div class="col-md-2 mb-3">
                              <label for="estadoNuevaTarea">Estado</label>
                              <select class="form-control" id="estadoNuevaTarea" name="estadoNuevaTarea" required>
                                <?php

                                  $sqlEstadoNuevaTarea = "  
                                    SELECT *
                                      FROM estado;

                                  ";

                                  $queryEstadoNuevaTarea = mysqli_query($conectar, $sqlEstadoNuevaTarea);

                                  while ($rowEstadoNuevaTarea = mysqli_fetch_assoc($queryEstadoNuevaTarea)){

                                      echo '<option value="'.$rowEstadoNuevaTarea['id_estado'].'">'.$rowEstadoNuevaTarea['nombre_estado'].'</opction>';

                                  }

                                ?>
                              </select>                      
                          </div>
                          <div class="col-md-2 mb-3">
                              <label for="categoriaNuevaTarea">Categoría</label>
                              <select class="form-control" id="categoriaNuevaTarea" name="categoriaNuevaTarea" required>
                                <?php

                                  $sqlCategoriaNuevaTarea = "  
                                    SELECT *
                                      FROM categoria;

                                  ";

                                  $queryCategoriaNuevaTarea = mysqli_query($conectar, $sqlCategoriaNuevaTarea);

                                  while ($rowCategoriaNuevaTarea = mysqli_fetch_assoc($queryCategoriaNuevaTarea)){

                                    echo '<option value="'.$rowCategoriaNuevaTarea['id_categoria'].'">'.$rowCategoriaNuevaTarea['nombre_categoria'].'</opction>';

                                  }

                                ?>
                              </select>
                              
                          </div>

                      </div>
                     
                      <div class="form-group my-2">
                        <button class="btn btn-success" type="submit" name="crearNuevaTarea">Crear Tarea</button>
                      </div>
                  </form>
                </div>
            </div><!--Fin Modal Nueva Tarea-->


<!--Modal Estado-->
<div class="modal fade" id="modalEstadoUsuario" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Modificar Estado</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
              		<div class="card mb-4">
				        <div class="card-body">
				            <form name="fromuCambiarEstadoUsu" id="" action="" method="POST">
				                <label for="estado">Estado</label>
                                    <select class="form-control" id="estado" name="estado" aria-describedby="rolHelp">
                                        <option value="<?php echo $rowUsuarios['id_estado']; ?>">---<?php echo $rowUsuarios['nombre_estado']; ?>---</option><!--El primer rol que aparece es el que el usuario tiene por defecto.-->

                                            <?php #hacemos la query para ingresar los nombres de los roles en las options
                                                $sqlEstadoUsu = "
                                                  SELECT *
                                                    FROM estadousu;

                                                ";

                                                $queryEstadoUsu = mysqli_query($conectar, $sqlEstadoUsu);
                                                while($rowEstadoUsu = mysqli_fetch_assoc($queryEstadoUsu)) {

                                                  echo '<option value="'.$rowEstadoUsu['id_estado'].'">'.$rowEstadoUsu['nombre_estado'].'</option>';

                                                      }

                                            ?>
                                                
                                    </select>
                                    <br>
				                <div class="card-footer bg-white">
						            <button type="submit" class="btn btn-primary" name="cambiarEstadoUsuario">Cambiar</button>
						        </div>
				            </form>
				        </div>
				        
				    </div>
                </div>

                
            </div>
        </div>
    </div>





<!--Fin Modal Estado-->
 


   <!--Modal Perfil -->            
 <div class="modal fade" id="modalPerfil" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Datos de <?php echo $_SESSION['nombreUsu']?></h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                 </button>
             </div>
        
        <div class="card-body">
            <form name="actualizarUser" action="" method="POST" >
                                <div class="modal-body">
                                   <div class="card mb-4">
                                      
                                      <div class="card-body">
                                          
                                              <div class="form-group">
                                                  <label for="identificador">ID</label>
                                                  <input type="number" class="form-control" id="identificador" name="identificador" aria-describedby="idHelp" placeholder="Id" value="<?php echo $_SESSION['idUsu']; ?>" readonly>
                                                   <br>
                                                  
                                             
                                                  <label for="nombre">Nombre</label>
                                                  <input type="text" class="form-control" id="nombre" name="nombre" aria-describedby="nombreHelp" placeholder="Nombre" value="<?php echo $rowUsuarios['nombre_usuario'];?>">
                                                   <br>
                                                  
                                              
                                                  <label for="apellido">Apellido</label>
                                                  <input type="text" class="form-control" id="apellido" name="apellido" aria-describedby="apellidoHelp" placeholder="Apellido" value="<?php echo $rowUsuarios['apellido_usuario'];?>">
                                                   <br>
                                                  
                                              
                                                  <label for="email">Email</label>
                                                  <input type="email" class="form-control" id="email" name="correo" aria-describedby="emailHelp" placeholder="Email" value="<?php echo $rowUsuarios['correo_usuario'];?>" readonly>
                                                  <small>Debe contactar con el administrador para modificar su correo</small>
                                                  <br>
                                                   <br>    

                                                  <label for="fechaNacimiento">Fecha de Nacimiento*</label>
                                                  <input type="date" class="form-control" id="fdn" name="fdn" aria-describedby="fdnHelp" value="<?php echo $rowUsuarios['fdn_usuario'];?>">
                                                   <br>                                             
                                              
                                                  <label for="telefono">Teléfono</label>
                                                  <input type="tel" class="form-control" id="telefono" name="telefono" aria-describedby="telefonoHelp" placeholder="Teléfono" value="<?php echo $rowUsuarios['telefono_usuario'];?>">
                                                 

                                                   
                                                   <!--<label for="contrasena">Nueva Contraseña</label><br>
                                                 <input type="password" class="form-control" id="contrasena" name="contrasena" aria-describedby="claveHelp" placeholder="Contraseña" value="">-->
                                              </div>
                                              
                                          
                                      </div>
                                  </div>
                                </div>

                                  <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                      <button type="submit" class="btn btn-primary" name="cambiarDatosUsuario">Guardar</button>
                                  </div>
                              </form>
                              <form action="" name="modificaClave" method="POST">
                                                
                                  <!--Modal cambio de Contraseña -->
                                                 <div class="collapse" id="claveUsu<?php echo $rowUsuarios['id_usuario']?>" style="">
                                                  
                                                    <div class="card card-body">
                                                      <!--Ingresamos un campo invisible para poder obtener el id del usuario-->
                                                      <input type="number" class="form-control" id="identificadorClave" name="identificadorClave" aria-describedby="idHelp" placeholder="Id" value="<?php echo $rowUsuarios['id_usuario']; ?>" readonly hidden>
                                                   <br>
                                                        <label for="ingresaClaveNueva">Ingresar Nueva Contraseña</label>
                                                        <input type="password" class="form-control" id="contrasena" name="contrasena" aria-describedby="claveHelp" placeholder="Contraseña" value="">
                                                        <br>
                                                        <label for="repiteClaveNueva">Repetir Nueva Contraseña</label>
                                                        <input type="password" class="form-control" id="repiteContrasena" name="repiteContrasena" aria-describedby="claveHelp" placeholder="Repite Contraseña" value="">
                                                        <br>
                                                        <div class="modal-footer">
                                                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                                          <button type="submit" class="btn btn-primary" name="cambiarClave">Guardar</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                   <button class="btn btn-danger" type="button" data-toggle="collapse" data-target="#claveUsu<?php echo $rowUsuarios['id_usuario']?>" aria-expanded="true" >Modificar Contraseña</button> 
                                                </div>
                                                </form>
        </div>
        
                                
        </div>
    </div>
 </div><!--Fin Modal Perfil -->


<?php

}
?>




	
	<div class="row justify-content-around mt-5">
		<div class="columna1">
			<h1>Pendientes</h1>
			<div class="pendientes connectedSortable">
				
				<!-- <div class="tarea">
					<div class="urgencia"></div>
					<div class="tarjeta">
						<h2 class="titulo">Título</h2>
						<p class="descripcion">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
						<p class="fechaYhora">2020-05-10</p><p>2020-05-10</p>
					</div>
				</div> -->
			</div>
		</div>
		<div class="columna2">
			<h1>En Proceso</h1>
			<div class="enProgreso connectedSortable"></div>
		</div>
		<div class="columna3">
			<h1>Finalizadas</h1>
			<div class="completadas connectedSortable"></div>
		</div>
	</div class="row">






	<!-- SCRIPTS -->
	<script type="text/javascript" src="vendor/jquery/jquery-3.5.1.min.js"></script>
	<script type="text/javascript" src="vendor/jqueryUI/js/jquery-ui.min.js"></script>
	<script type="text/javascript" src="assets/js/script.js"></script>

	<!--<script src="assets/js/jquery.min.js"></script>-->
	<script src="assets/js/bootstrap.bundle.min.js"></script>
	<script src="assets/js/bootadmin.min.js"></script>
	<script src="assets/js/datatables.min.js"></script>
	<script src="assets/js/moment.min.js"></script>
	<script src="assets/js/fullcalendar.min.js"></script>
	<script src="assets/js/bootstrap.bundle.min.js"></script>

	<script type="text/javascript">
		
		
		var valorId =""; /*variable que se lleva el id de la tarea que movemos de columna*/
    var valorId2 ="";
    var valorId3 ="";
		var f = ""; /*variable que llevará la fecha actual*/


		//creamos dos variables que van a controlar si la cantidad de tareas ha cambiado
		var tareasOLD = "";
        var tareasNEW = "";
	

        //Primera funcion ajax para insertar los datos. En cuanto se abra la pagina se cargan los datos.
		$.ajax({

			url: 'https://jaenwebdesign.com/PHP/Proyecto/ajax/tareas.app.php',
			type: 'GET',
			success: function(tareas){

				$.each(tareas, function(i, tarea){
					var id = tarea.id_tarea;
					var titulo = tarea.nombre_tarea;
					//console.log(titulo);
					var descripcion = tarea.descripcion_tarea;
					//console.log(descripcion);
					var fecha = tarea.fdc_tarea;
					//console.log(fecha); 
					var hora = tarea.fda_tarea;
					//console.log(hora); 
					var color = tarea.color_categoria;
					//console.log(colorcito); 
					var estado = tarea.id_estado;


					if (estado == 1){
						$(".pendientes").append('<div id="t'+id+'" class="tarea" style="border-left: solid 20px '+color+';"><div class="urgencia" style="background: '+color+'; text-align:center;"></div><div class="tarjeta"><h2 class="titulo">'+titulo+'</h2><p class="descripcion">'+descripcion+'</p><div class="row justify-content-around"><p class="fechaYhora">Creado el  '+fecha+'</p><p class="fechaYhora">Actualizado  '+hora+'</p></div></div></div>');



					}else if(estado == 2){

						$(".enProgreso").append('<div id="t'+id+'" class="tarea" style="border-left: solid 20px '+color+';"><div class="urgencia" style="background: '+color+'; text-align:center;"></div><div class="tarjeta"><h2 class="titulo">'+titulo+'</h2><p class="descripcion">'+descripcion+'</p><div class="row justify-content-around"><p class="fechaYhora">Creado el  '+fecha+'</p><p class="fechaYhora">Actualizado  '+hora+'</p></div></div></div>');

					}else if(estado == 3){

						$(".completadas").append('<div id="t'+id+'" class="tarea" style="border-left: solid 20px '+color+';"><div class="urgencia" style="background: '+color+'; text-align:center;"></div><div class="tarjeta"><h2 class="titulo">'+titulo+'</h2><p class="descripcion">'+descripcion+'</p><div class="row justify-content-around"><p class="fechaYhora">Creado el  '+fecha+'</p><p class="fechaYhora">Actualizado  '+hora+'</p></div></div></div>');

					}


/* DROPPABLE */
					$(function(){
			    	$(".pendientes, .enProgreso, .completadas").sortable({
			    		connectWith: ".connectedSortable"
			    		
			    	}).disableSelection();
		        	});

		        	var f = new Date();

						var anio  = f.getFullYear().toString();
						var mes = (f.getMonth()+1).toString().padStart(2,0);
						var dia   = f.getDate().toString().padStart(2,0);
						var fechaAct =  anio + '-' + mes + '-' + dia;

			   			/*Obtiene el id de la tarea que estamos moviendo*/
			    	 $(".tarea").mousedown(function(){

			    	 	valorId = $(this).attr("id");
					     valorId = valorId.substring(1);
					     console.log(valorId);
					   
			    	 });

			    	 /*Modifica el estado y la fecha de actualización mediante Ajax*/
			    	$(".pendientes").droppable({
			    		drop: function(event, ui) {
				        $.ajax({
				        	url: 'https://jaenwebdesign.com/PHP/Proyecto/ajax/updateTarea.app.php',
				        	type: 'GET',

				        	data: {'estadoTarea': 1, 'idTarea': valorId, 'actualizaTarea': fechaAct},

				        	success: function() {
				        		console.log('tarea MOdificada');
				        		console.log(valorId);
                    window.location.assign("main.php");
				        	}
				        });
				          
				      }
			    		
			    	});/*Fin droppable .pendientes*/

			    		/*Obtiene el id de la tarea que estamos moviendo*/
			    	$(".tarea").mousedown(function(){

			    	 	valorId = $(this).attr("id");
					     valorId = valorId.substring(1);
					     console.log(valorId);
					   
			    	 });

			    	/*Modifica el estado y la fecha de actualización mediante Ajax*/
			    	$(".enProgreso").droppable({
			    		drop: function(event, ui) {
				        $.ajax({
				        	url: 'https://jaenwebdesign.com/PHP/Proyecto/ajax/updateTarea.app.php',
				        	type: 'GET',

                  data: {'estadoTarea': 2, 'idTarea': valorId, 'actualizaTarea': fechaAct},

				        	success: function() {
				        		console.log('tarea MOdificada');
				        		console.log(valorId);
                    window.location.assign("main.php");
				        	}
				        });
				          
				      }
			    		
			    	});/*Fin droppable .enProgreso*/

			    		/*Obtiene el id de la tarea que estamos moviendo*/
			    	$(".tarea").mousedown(function(){

			    	 	valorId = $(this).attr("id");
					     valorId = valorId.substring(1);
					     console.log(valorId);
					   
			    	 });

			    	/*Modifica el estado y la fecha de actualización mediante Ajax*/
			    	$(".completadas").droppable({
			    		drop: function(event, ui) {
				        $.ajax({
				        	url: 'https://jaenwebdesign.com/PHP/Proyecto/ajax/updateTarea.app.php',
				        	type: 'GET',

				        	data: {'estadoTarea': 3, 'idTarea': valorId, 'actualizaTarea': fechaAct},

				        	success: function() {
				        		console.log('tarea MOdificada');
				        		console.log(valorId);
                    window.location.assign("main.php");
				        	}
				        });
				          
				      }
			    		
			    	});/*Fin droppable .completadas*/



				});

			},


			error: function(){
				console.log('Error NO es posible encontrar el archivo de la petición JSON.');
			}
		});



		setInterval(function(){ //cada 5 segundos:


           
            $.ajax({

                url: 'https://jaenwebdesign.com/PHP/Proyecto/ajax/tareas.app.php',
                type: 'GET',/*peticion en GET para que puedan ser utlizadas en m'ovil*/
              success: function(tareas){
                    tareasNEW = tareas; //La segunda vez que se carga almacenamos el array en esta otra variable.
                    
                    if(tareasOLD === tareasNEW){
                        //si no coinciden las variable, ingresa nuevamente los datos
                    }else{
                    $(".pendientes").html("");
                    $(".enProgreso").html("");
                    $(".completadas").html("");

                    //eliminamos lo que aparece en el html y volvemos a cargarlo.
                      
                    $.each(tareas, function(i, tarea){
                    var id = tarea.id_tarea;
					var titulo = tarea.nombre_tarea;
					//console.log(titulo);
					var descripcion = tarea.descripcion_tarea;
					//console.log(descripcion);
					var fecha = tarea.fdc_tarea;
					//console.log(fecha); 
					var hora = tarea.fda_tarea;
					//console.log(hora); 
					var color = tarea.color_categoria;
					//console.log(colorcito); 
					var estado = tarea.id_estado;

			if (estado == 1){
				$(".pendientes").append('<div id="t'+id+'" class="tarea" style="border-left: solid 20px '+color+';"><div class="urgencia" style="background: '+color+'; text-align:center;"></div><div class="tarjeta"><h2 class="titulo">'+titulo+'</h2><p class="descripcion">'+descripcion+'</p><div class="row justify-content-around"><p class="fechaYhora">Creado el  '+fecha+'</p><p class="fechaYhora">Actualizado  '+hora+'</p></div></div></div>');


			}else if(estado == 2){

				$(".enProgreso").append('<div id="t'+id+'" class="tarea" style="border-left: solid 20px '+color+';"><div class="urgencia" style="background: '+color+'; text-align:center;"></div><div class="tarjeta"><h2 class="titulo">'+titulo+'</h2><p class="descripcion">'+descripcion+'</p><div class="row justify-content-around"><p class="fechaYhora">Creado el  '+fecha+'</p><p class="fechaYhora">Actualizado  '+hora+'</p></div></div></div>');

			}else if(estado == 3){

				$(".completadas").append('<div id="t'+id+'" class="tarea" style="border-left: solid 20px '+color+';"><div class="urgencia" style="background: '+color+'; text-align:center;"></div><div class="tarjeta"><h2 class="titulo">'+titulo+'</h2><p class="descripcion">'+descripcion+'</p><div class="row justify-content-around"><p class="fechaYhora">Creado el  '+fecha+'</p><p class="fechaYhora">Actualizado  '+hora+'</p></div></div></div>');

			}

			});

                    $(function(){
	    	$(".pendientes, .enProgreso, .completadas").sortable({
	    		connectWith: ".connectedSortable"
	    		
	    	}).disableSelection();

	   
	    	 $(".tarea").mousedown(function(){

	    	 	valorId = $(this).attr("id");
			     valorId = valorId.substring(1);
			     console.log(valorId);
			   
	    	 });

	    	$(".pendientes").droppable({
	    		drop: function(event, ui) {
		        $.ajax({
		        	url: 'https://jaenwebdesign.com/PHP/Proyecto/ajax/updateTarea.app.php',
		        	type: 'GET',

		        	data: {'estadoTarea': 1, 'idTarea': valorId},

		        	success: function() {
		        		console.log('tarea MOdificada');
		        	}
		        });
		          
		      }
	    		
	    	});

        $(".enProgreso").droppable({
          drop: function(event, ui) {
            $.ajax({
              url: 'https://jaenwebdesign.com/PHP/Proyecto/ajax/updateTarea.app.php',
              type: 'GET',

              data: {'estadoTarea': 2, 'idTarea': valorId},

              success: function() {
                console.log('tarea MOdificada');
              }
            });
              
          }
          
        });

          $(".completadas").droppable({
          drop: function(event, ui) {
            $.ajax({
              url: 'https://jaenwebdesign.com/PHP/Proyecto/ajax/updateTarea.app.php',
              type: 'GET',

              data: {'estadoTarea': 3, 'idTarea': valorId},

              success: function() {
                console.log('tarea MOdificada');
              }
            });
              
          }
          
        });



	  	});

            tareasOLD = tareasNEW;

            }
    

          },
            error: function(){
             $("#mensaje").html('Error NO es posible encontrar el archivo de la petición JSON.');
                }

            });

        }, 50000  );


     


  //MODIFICA EL ALTO DEL TEXT AREA DEL FORMULARIO
  $('#DescripcionNuevaTarea').focus( function() {

  // CAMBIA EL ALTO 
  $(this).animate({ height: 100 }, 'slow');
}).blur( function(e) {
  // LO DEVUELVE A SU TAMAÑO ORIGINAL
  $(this).animate({ height: '34px' }, 'slow');
});
	</script>

</body>
</html>