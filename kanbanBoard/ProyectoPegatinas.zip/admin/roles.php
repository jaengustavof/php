<?php
  
  session_start();

  #su no existe variable de session lo lleva al index.
  if(!isset($_SESSION['idUsu'])) {

    header('Location: index.php');
  }

  #si no tiene permiso de administrador se redirecciona al index.
  if($_SESSION['rolUsu'] != 1){
    header('Location: index.php');
  }

  #si existe la session, iniciamos la conexión a la base de datos

  require '../includes/conexion.inc.php';



  if($_POST){


  	#=========================================
    #CREAR NUEVO ROL
    #=========================================
  	if(isset($_POST['crearNuevoRol'])){
  		$sqlCreaRol = "  
  			INSERT INTO rol
  				VALUES (null, '".$_POST['nombreNuevoRol']."');
  		";


  		$queryCreaRol = mysqli_query($conectar, $sqlCreaRol);

  		echo '<div class="alert alert-success" role="alert">
                Rol creado correctamente.
            </div>';
  	}else{
        echo '<div class="alert alert-danger" role="alert">
                Todos los campos son obligatorios.
            </div>';
      }






    #=========================================
    #EDITAR ROL
    #=========================================

  	if(isset($_POST['modificarRol'])){

  		if((isset($_POST['idModificarRol']) && !empty($_POST['idModificarRol'])) && (isset($_POST['nombreModificarRol']) && !empty($_POST['nombreModificarRol']))){

  				$sqlActualizarRol = "  

  				UPDATE rol 
  						SET nombre_rol = '".$_POST['nombreModificarRol']."'
  						WHERE id_rol LIKE ".$_POST['idModificarRol'].";

  				";

  				$queryActualizarRol = mysqli_query($conectar, $sqlActualizarRol);

  				echo '<div class="alert alert-success" role="alert">
                Rol modificado correctamente.
            </div>';

  		}else{
        echo '<div class="alert alert-danger" role="alert">
                Todos los campos son obligatorios.
            </div>';
      }


  	}


  	#=========================================
    #ELIMINAR ROL
    #=========================================
  	if(isset($_POST['modalEliminarRol'])){
  		
  	


  		$sqlEliminaRol = "  
  			DELETE FROM rol
  				WHERE id_rol LIKE ".$_POST['idRolEliminar'].";
  		";


  		$queryEliminaRol = mysqli_query($conectar, $sqlEliminaRol);

  		echo '<div class="alert alert-success" role="alert">
                Rol eliminado correctamente.
            </div>';
  	}else{
        echo '<div class="alert alert-danger" role="alert">
                Todos los campos son obligatorios.
            </div>';
      }


  }

?>


<!DOCTYPE html>
<html lang="en">
<head>



    <!--META-->
        <meta charset="UTF-8"> 
        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!--retrocompatible con microsoft edge-->
        <meta name="author" content=""><!-- quien hace la pagina web / desarrollador -->
        <meta name="copyright" content=""><!--derecho de copyright / derechos de explotacion / es a empresa-->
        <meta name="contact" content=""> <!--se especifica correo electronico de la persona que lleva el mantenimiento del sitio-->
        <meta name="description" content=""> <!--descripcion de la pagina web-->
        <meta name="keywords" content=""> <!--palabras clave por las que se indexan-->
        <meta name="robots" content="NoIndex, NoFollow"> <!--sustituye al robots.txt / el dia que se indexe cambia el content-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, shrink-to-fit=no">	

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/fontawesome-all.min.css">
    <link rel="stylesheet" href="css/bootadmin.min.css">
    <link rel="stylesheet" href="css/datatables.min.css">

    <link rel="icon" type="icon/png" href="fav.png">


    <title>Pegatinas | Roles</title>
</head>
<body class="bg-light">



<nav class="navbar navbar-expand navbar-dark bg-primary">
    <a class="sidebar-toggle mr-3" href="#"><i class="fa fa-bars"></i></a>
    <a class="navbar-brand" href="main.php">Pegatinas</a>

    <div class="navbar-collapse collapse">
        <ul class="navbar-nav ml-auto">
            
            <li class="nav-item dropdown">
                <a href="#" id="dd_user" class="nav-link dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> 
                	<!-- para que aparezca el nombre en la parte superior derecha -->
                	<?php echo $_SESSION['nombreUsu']?>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dd_user">
                    <a href="#" class="dropdown-item" data-toggle="modal" data-target="#modalPerfil">Perfil</a>

                    <a href="cerrar.php" class="dropdown-item">Cerrar Sesión</a>
                </div>
            </li>
        </ul>
    </div>

</nav>
<!--Modal Perfil -->
               
 <div class="modal fade" id="modalPerfil" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Datos de <?php echo $_SESSION['nombreUsu']?></h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                 </button>
             </div>
             <div class="card card-body">
                                <!--Los datos del admin se mostrarán en modo readonly en el apartado de perfil -->
            <form action="" method="" name="formuDatosAdmin">
               <label for="idAdmin">ID</label>
               <input type="number" class="form-control" id="idAdmin" name="idAdmin" value="<?php echo $_SESSION['idUsu']?>" readonly>
<br>
               <label for="nombreAdmin">Nombre</label>
              <input type="text" class="form-control" id="nombreAdmin" name="nombreAdmin" value="<?php echo $_SESSION['nombreUsu']?>" readonly>
<br>
              <label for="emailAdmin">Correo</label>
               <input type="email" class="form-control" id="emailAdmin" name="emailAdmin" value="<?php echo $_SESSION['correoUsu']?>" readonly>
<br>
               <label for="telAdmin">Tel</label>
              <input type="tel" class="form-control" id="telAdmin" name="telAdmin" value="<?php echo $_SESSION['telefonoUsu']?>" readonly>

             
               <br>
               <br>

             </form>
             </div>
                                
         </div>
    </div>
 </div><!--Fin Modal Perfil -->


<div class="d-flex">
    <div class="sidebar sidebar-dark bg-dark">
        <ul class="list-unstyled">
            <li><a href="tareas.php"><i class="fa fa-fw fa-link"></i> Tareas</a></li>
            <li><a href="usuarios.php"><i class="fa fa-fw fa-link"></i> Usuarios</a></li>
            <li><a href="participante.php"><i class="fa fa-fw fa-link"></i> Participante</a></li>
            <li><a href="#"><i class="fa fa-fw fa-link"></i> Roles</a></li>
            <li><a href="areaCateg.php"><i class="fa fa-fw fa-link"></i> Area / Categoría</a></li>
            <li><a href="estadousuario.php"><i class="fa fa-fw fa-link"></i> Estados Usuarios</a></li>


        </ul>
    </div>

    <div class="content p-4">
      <h2 class="mb-4">Roles</h2>



      	 <!--Modal de Nuevo Rol -->
      	<div class="my-3">
        	<button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#nuevoRol" aria-expanded="false" >Nuevo Rol</button>
      	</div>

      <div class="collapse my-3" id="nuevoRol" style="">
                <div class="card card-body">
                    <form name="formuNuevoRol" method="POST">
                      <div class="form-row">
                          <div class="col-md-2 mb-3">
                              <label for="nombreNuevoRol">Nombre</label>
                                  <input type="text" class="form-control" id="nombreNuevoRol" name="nombreNuevoRol" placeholder="Nombre" value="" required>
    
                          </div>

                      	</div>

                     
                      <div class="form-group my-2">
                        <button class="btn btn-primary" type="submit" name="crearNuevoRol">Crear Rol</button>
                      </div>
                  </form>
                </div>
            </div>







      <div class="card mb-4">
        <div class="card-body">
            <div id="example_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
              
              <div class="row">
                      <div class="col-sm-12">
                        <table id="example" class="table table-hover dataTable no-footer dtr-inline" cellspacing="0" width="100%" role="grid" aria-describedby="example_info" style="width: 100%;">
                <thead>
                <tr role="row">
                <th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 85.5px;" aria-sort="ascending" aria-label="Name: activate to sort column descending">Id</th>

                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 120.5px;" aria-label="Position: activate to sort column ascending">Nombre</th>

                
                <th class="actions sorting_disabled" rowspan="1" colspan="1" style="width: 100px;" aria-label="Actions">Acciones</th>
                </tr>
                </thead>


            <tbody>

               <?php
                  #realizamos la consulta en la base de datos para ingresar la informacio'n de las tareas en la tabla. Los JOIN son para poder ingresar los nombres de estados y las categorías.
                    $sqlRoles = "  

                      SELECT *
                        FROM rol
                          


                    ";

                    $queryRoles = mysqli_query($conectar, $sqlRoles);

                    while ($rowRoles = mysqli_fetch_assoc($queryRoles)){
                         
                      ?>
                      <!--Modal cambio de datos -->

                        <div class="modal fade show" id="modalRol<?php echo $rowRoles['id_rol'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalTArea" style="display: none;" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalRol"><?php echo $rowRoles['nombre_rol'];?></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form name="formuActualizaTarea" action="" method="POST">

                                        <div class="modal-body">
		                                   <div class="card mb-4">
		                                      
		                                      <div class="card-body">
		                                          
		                                              <div class="form-group">
		                                                  <label for="idModificarRol">ID</label>
		                                                  <input type="number" class="form-control" id="idModificarRol" name="idModificarRol" aria-describedby="idHelp" placeholder="Id" value="<?php echo $rowRoles['id_rol']; ?>" readonly>
		                                                   <br>

		                                                  <label for="nombreModificarRol">Nombre*</label>
		                                                  <input type="text" class="form-control" id="nombreModificarRol" name="nombreModificarRol" aria-describedby="nombreHelp" placeholder="Nombre Rol" value="<?php echo $rowRoles['nombre_rol'];?>">
		                                                   <br>
		                                              </div>
		                                              
		                                          
		                                      </div>
		                                  </div>
		                                </div>

		                                  <div class="modal-footer">
		                                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
		                                      <button type="submit" class="btn btn-primary" name="modificarRol">Guardar</button>
		                                  </div>
		                              </form>
                                      

                                
                                </div>

                            </div>
                        </div>
                    </div> <!--Fin modal editar Rol -->

                    <!-- Modal Eliminar Rol -->
                    <div class="modal fade" id="eliminarRol<?php echo $rowRoles['id_rol'];?>" tabindex="-1" role="dialog"  style="display: none;" aria-hidden="true">
                      <div class="modal-dialog modal-dialog-centered" role="document">
                          <div class="modal-content">
                              <div class="modal-header">
                                  <h5 class="modal-title" id="eliminarRol">Eliminar Rol: <?php echo $rowRoles['nombre_rol'];?></h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">×</span>
                                  </button>
                              </div>
                              <div class="modal-body">
                                <form action="" name="formuEliminarRol" method="POST">

                                  <p>¿Está seguro que desea eliminar al siguiente Rol?</p>
                                  <label for="idRolEliminar">ID Rol</label>
                                  <input type="number" class="form-control" id="idRolEliminar" name="idRolEliminar" value="<?php echo $rowRoles['id_rol'];?>">
                                  <br>
                                  <label for="nombreRolEliminar">Nombre Rol</label>
                                  <input type="text" class="form-control" id="nombreRolEliminar" name="nombrRolEliminar" value="<?php echo $rowRoles['nombre_rol'];?>">
                                  <br>
                                   <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                     <button  class="btn btn-danger" type="submit" name="modalEliminarRol">Eliminar</button>
                                   </div>
                                </form>
                                  
                              </div>
                             
                                </div>
                            </div>
                      </div>


                      <?php

                         echo '
                        <tr role="row" class="odd">
                          <td tabindex="0" class="sorting_1">'.$rowRoles['id_rol'].'</td>
                          <td>'.$rowRoles['nombre_rol'].'</td>
                          <td class=" actions">
                              <a href="#" class="btn btn-icon btn-pill btn-primary" data-toggle="modal" data-target="#modalRol'.$rowRoles['id_rol'].'"><i class="fa fa-fw fa-edit"></i></a>


                              <a href="#" class="btn btn-icon btn-pill btn-danger" data-toggle="modal" data-target="#eliminarRol'.$rowRoles['id_rol'].'"><i class="fa fa-fw fa-trash"></i></a>
                          </td>
                        </tr>
                        
                      ';
                    }

                      


                      ?>
                 


              </tbody>
            </table>


              



            <div id="example_processing" class="dataTables_processing card" style="display: none; ">Procesando...</div></div></div><div class="row pt-3" style="border-top: 1px solid rgba(0,0,0,0.2);"><div class="col-sm-12 col-md-5"><div class="dataTables_info" id="example_info" role="status" aria-live="polite" >Mostrando 1 al 25 de <?php echo mysqli_num_rows($queryRoles); #cuenta la cantidad de filas de la query ?> entradas</div></div><div class="col-sm-12 col-md-7"><div class="dataTables_paginate paging_simple_numbers" id="example_paginate"><ul class="pagination"><li class="paginate_button page-item previous disabled" id="example_previous"><a href="#" aria-controls="example" data-dt-idx="0" tabindex="0" class="page-link">Anterior</a></li><li class="paginate_button page-item active"><a href="#" aria-controls="example" data-dt-idx="1" tabindex="0" class="page-link">1</a></li><li class="paginate_button page-item "><a href="#" aria-controls="example" data-dt-idx="2" tabindex="0" class="page-link">2</a></li><li class="paginate_button page-item "><a href="#" aria-controls="example" data-dt-idx="3" tabindex="0" class="page-link">3</a></li><li class="paginate_button page-item next" id="example_next"><a href="#" aria-controls="example" data-dt-idx="4" tabindex="0" class="page-link">Siguiente</a></li></ul></div></div></div></div>
        </div>
    



    </div>


     </div>
 </div>


 <script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/bootadmin.min.js"></script>
<script src="js/datatables.min.js"></script>
<script src="js/moment.min.js"></script>
<script src="js/fullcalendar.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>

 


        </script>
</body>
</html>