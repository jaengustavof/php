<?php
	
	session_start();

	#su no existe variable de session lo lleva al index.
	if(!isset($_SESSION['idUsu'])) {

		header('Location: index.php');
	}

  #si no tiene permiso de administrador se redirecciona al index.
  if($_SESSION['rolUsu'] != 1){
    header('Location: index.php');
  }

	#si existe la session, iniciamos la conexión a la base de datos

	require '../includes/conexion.inc.php';

  #para poder utlizar el php mailer
  use PHPMailer\PHPMailer\PHPMailer;
  use PHPMailer\PHPMailer\Exception;

  require '../includes/Exception.php';
  require '../includes/PHPMailer.php';
  require '../includes/SMTP.php';

  



#==============================================================
#controlamos si hay un formulario enviado por POST
#==============================================================

  if($_POST){
    #======================================================================================================
    # Crear usuario / $_POST['crearNuevoUsuario'] pertenece al bot'on del form para actualizar datos.
    #======================================================================================================
    
    if(isset($_POST['crearNuevoUsuario'])) {
 
      #campos opcionales
        if(!isset($_POST['telReg'])) {

          $telefonoReg = "";

        }else{

          $telefonoReg = $_POST['telReg'];

        }

        if(!isset($_POST['generoReg'])) {

          $generoReg = "";

        }else{

          $generoReg = $_POST['generoReg'];

        }

        if(!isset($_POST['validadoReg'])) {

          $validadoReg = 0;

        }else{

          $validadoReg = 1;

        }

        

        
        
        #campos obligatorios
      if((isset($_POST['nombreReg']) && !empty($_POST['nombreReg'])) && (isset($_POST['apellidoReg']) && !empty($_POST['apellidoReg'])) && (isset($_POST['emailReg']) && !empty($_POST['emailReg'])) && (isset($_POST['claveReg']) && !empty($_POST['claveReg'])) && (isset($_POST['fdnReg']) && !empty($_POST['fdnReg']))&& (isset($_POST['areaReg']) && !empty($_POST['areaReg']))  && (isset($_POST['rolReg']) && !empty($_POST['rolReg']))){  

          #Se comprueba si el correo ya fue registrado
          $registroEmail = 0;
          $emailUsuReg = $_POST['emailReg'];

          $sqlComprobarCorreo = "  
            SELECT correo_usuario AS emailUsu
              FROM usuario;

          ";

          $queryComprobarCorreo = mysqli_query($conectar,$sqlComprobarCorreo);

          while ($rowComprobarCorreo = mysqli_fetch_assoc($queryComprobarCorreo)) {

            if($rowComprobarCorreo['emailUsu'] == $emailUsuReg ){

              echo '<div class="alert alert-danger" role="alert">
                Correo Ya Registrado!
            </div>';
              $registroEmail = 1;
            }
          }


          if($registroEmail == 0) {
            #Se ingresan los datos del nuevo usuario a la BBDD. Por defecto los usuarios registrados aparecen Activos y Offline.
            $sqlNuevoUsuario = "   
              INSERT INTO usuario
                VALUES (null, '".$_POST['nombreReg']."','".$_POST['apellidoReg']."','".$_POST['emailReg']."','".password_hash($_POST['claveReg'], PASSWORD_DEFAULT)."','".$_POST['fdnReg']."','".$telefonoReg."', '".$generoReg."', '".$validadoReg."', 1,'".$_POST['areaReg']."',  '".$_POST['rolReg']."', 2);;
            ";

            $queryNuevoUsuario = mysqli_query($conectar, $sqlNuevoUsuario);

            echo '<div class="alert alert-success" role="alert">
                Usuario creado correctamente.
            </div>';
            #=================================#
          # Envia email para validar cuenta #
          #=================================#
            if($validadoReg == 0) {
               $receptor = $_POST['emailReg'];
          $nombre = $_POST['nombreReg'];
        
           //Crea el objeto
       $correoElectronico = new PHPMailer;
        // Emisor
        $correoElectronico->setFrom('info@jaenwebdesign.com', 'Pegatinas');
        // Receptor
        $correoElectronico->addAddress($receptor, $nombre );
        // Asunto
        $correoElectronico->Subject = 'valida tu cuenta';
       
        //$correoElectronico->msgHTML('Valida tu cuenta');
       $correoElectronico->msgHTML('Para validar tu cuenta pulsa <a href="https://jaenwebdesign.com/PHP/Proyecto/validar.php?correo='.$_POST['emailReg'].'">AQUÍ</a>');
      
        // Codificación de Caracteres
        $correoElectronico->CharSet = 'UTF-8';

        // Enviar mensaje verificando posibles errores
        if (!$correoElectronico->send()){
            echo 'Error al enviar: '.$correoElectronico->ErrorInfo;
        }else{
            echo 'Mensaje enviado';
        }
              
            }
              

          }

      } 


    } # fin $_POST crearNuevoUsuario



    #===================================#
    # Enviar Correo al Usuairo          #
    #===================================#


    if(isset($_POST['enviarEmail'])){
        
      if((isset($_POST['correoContacto']) && !empty($_POST['correoContacto'])) && (isset($_POST['asuntoContacto']) && !empty($_POST['asuntoContacto'])) && (isset($_POST['mensajeContacto']) && !empty($_POST['mensajeContacto']))){

        $receptor = $_POST['correoContacto'];
        $asunto = $_POST['asuntoContacto'];
        $mensaje = $_POST['mensajeContacto'];
        //Crea el objeto
        $correoElectronico = new PHPMailer;

        // Emisor
        $correoElectronico->setFrom('info@jaenwebdesign.com', 'Info');

        // Receptor
        $correoElectronico->addAddress($receptor,'Gustavo');

        //Asunto
        $correoElectronico->Subject = $asunto;

        //Mensaje
        $correoElectronico->msgHTML($mensaje);



        //Enviar Mensaje verificando errores
          if (!$correoElectronico->send()){
              echo 'Error al enviar: '.$correoElectronico->ErrorInfo;
          }else{
              echo '<div class="alert alert-success" role="alert">
                Mensaje enviado correctamente.
            </div>';
          }



      }else{
        echo '<div class="alert alert-danger" role="alert">
                Todos los campos son obligatorios
            </div>';
      }

    } # Fin Enviar Correo al Usuairo 






    #======================================================================================================
    # Actualizar datos usuario / $_POST['cambiarDatos'] pertenece al bot'on del form para actualizar datos.
    #======================================================================================================

     if(isset($_POST['cambiarDatos'])) {
  

      if(!isset($_POST['telefono'])) {#es informacion opcional, si la completa se cambiar'a por la nueva. De lo contrario quedar'a la existente.

        $telefono = "";
      }else{

        $telefono = $_POST['telefono'];

      }


      if(!isset($_POST['genero'])) {#es informacion opcional, si la completa se cambiar'a por la nueva. De lo contrario quedar'a la existente.

        $genero = "";
      }else{

        $genero = $_POST['genero'];

      }


      if(!isset($_POST['validado'])){#es informacion opcional, si la completa se cambiar'a por la nueva. De lo contrario quedar'a la existente. Es 0 o 1 ya que son datos boolean.

        $validado = 0;

      }else{

        $validado = 1;

      }


      if(!isset($_POST['activo'])){#es informacion opcional, si la completa se cambiar'a por la nueva. De lo contrario quedar'a la existente. Es 0 o 1 ya que son datos boolean.

        $activo = 0;

      }else{

        $activo = 1;
        
      }





      if((isset($_POST['nombre']) && !empty($_POST['nombre'])) && (isset($_POST['apellido']) && !empty($_POST['apellido'])) && (isset($_POST['correo']) && !empty($_POST['correo'])) && (isset($_POST['fdn']) && !empty($_POST['fdn'])) && (isset($_POST['area']) && !empty($_POST['area'])) && (isset($_POST['rol']) && !empty($_POST['rol'])) && (isset($_POST['estadousu']) && !empty($_POST['estadousu'])) ) {


          #si los datos son correctos atualizamos la bbdd.

          $sqlCambiarDatos = "   
            UPDATE usuario
              SET nombre_usuario = '".$_POST['nombre']."',
                  apellido_usuario = '".$_POST['apellido']."',
                  correo_usuario = '".$_POST['correo']."',
                  fdn_usuario = '".$_POST['fdn']."',
                  telefono_usuario = '".$telefono."',
                  genero_usuario = '".$genero."',
                  validado_usuario = '".$validado."',
                  activo_usuario = '".$activo."',
                  id_area = '".$_POST['area']."',
                  id_rol = '".$_POST['rol']."',
                  id_estado = '".$_POST['estadousu']."'
                WHERE id_usuario LIKE ".$_POST['identificador'].";

          ";

          $queryCambiarDatos = mysqli_query($conectar, $sqlCambiarDatos);

          echo '<div class="alert alert-success" role="alert">
                Se han actualizado los datos correctamente.
            </div>';

    
      }else{

        echo '<div class="alert alert-danger" role="alert">
                Los datos obligatorios deben estar rellenos
            </div>';

      }

      
      /*fin isset($_POST['cambiarDatos']*/
  }

  if(isset($_POST['cambiarClave'])){
    #======================================================================================================
    # Modificar Contraseña / $_POST['cambiarClave'] pertenece al bot'on del form para actualizar datos.
    #======================================================================================================
      if((isset($_POST['contrasena']) && !empty($_POST['contrasena'])) && (isset($_POST['repiteContrasena']) && !empty($_POST['repiteContrasena'])) ) {

        #comprobamos que los campos ingresados sean iguales
        if($_POST['contrasena'] == $_POST['repiteContrasena']) {

          $sqlCambiarClave = " 
            UPDATE usuario
              SET clave_usuario = '".password_hash($_POST['contrasena'], PASSWORD_DEFAULT)."'
              WHERE id_usuario LIKE ".$_POST['identificadorClave'].";

          ";

          $queryCambiarClave = mysqli_query($conectar, $sqlCambiarClave);

         echo '<div class="alert alert-success" role="alert">
                Contraseña modificada correctamente.
            </div>';
          
        }else{

          echo '<div class="alert alert-danger" role="alert">
                Los campos ingresados no coinciden
            </div>';
        }

      }else {
        echo '<div class="alert alert-danger" role="alert">
                Falta completar unos campos
            </div>';
      }
      



  /*fin isset($_POST['cambiarClave']*/
  }

#======================================================================================================
# Eliminar Usuario / $_POST['eliminarUsuario'] pertenece al bot'on del form para actualizar datos.
#======================================================================================================
  if(isset($_POST['eliminarUsuario'])){

    $sqlEliminaUsuario = " 

      DELETE FROM usuario
        WHERE id_usuario LIKE ".$_POST['idEliminar'].";

    ";

    $queryEliminaUsuario = mysqli_query($conectar, $sqlEliminaUsuario);
    echo '<div class="alert alert-success" role="alert">
                Usuario eliminado.
            </div>';
  }



}
 





?>

<!DOCTYPE html>
<html lang="en">
<head>



    <!--META-->
        <meta charset="UTF-8"> 
        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!--retrocompatible con microsoft edge-->
        <meta name="author" content=""><!-- quien hace la pagina web / desarrollador -->
        <meta name="copyright" content=""><!--derecho de copyright / derechos de explotacion / es a empresa-->
        <meta name="contact" content=""> <!--se especifica correo electronico de la persona que lleva el mantenimiento del sitio-->
        <meta name="description" content=""> <!--descripcion de la pagina web-->
        <meta name="keywords" content=""> <!--palabras clave por las que se indexan-->
        <meta name="robots" content="NoIndex, NoFollow"> <!--sustituye al robots.txt / el dia que se indexe cambia el content-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, shrink-to-fit=no">	

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/fontawesome-all.min.css">
    <link rel="stylesheet" href="css/bootadmin.min.css">
    <link rel="stylesheet" href="css/datatables.min.css">

    <link rel="icon" type="icon/png" href="fav.png">


    <title>Pegatinas | Usuarios</title>
</head>
<body class="bg-light">



<nav class="navbar navbar-expand navbar-dark bg-primary">
    <a class="sidebar-toggle mr-3" href="#"><i class="fa fa-bars"></i></a>
    <a class="navbar-brand" href="main.php">Pegatinas</a>

    <div class="navbar-collapse collapse">
        <ul class="navbar-nav ml-auto">
            
            <li class="nav-item dropdown">
                <a href="#" id="dd_user" class="nav-link dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> 
                	<!-- para que aparezca el nombre en la parte superior derecha -->
                	<?php echo $_SESSION['nombreUsu']?>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dd_user">
                    <a href="#" class="dropdown-item" data-toggle="modal" data-target="#modalPerfil">Perfil</a>

                    <a href="cerrar.php" class="dropdown-item">Cerrar Sesión</a>
                </div>
            </li>
        </ul>
    </div>

</nav>
<!--Modal Perfil -->
               
 <div class="modal fade" id="modalPerfil" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Datos de <?php echo $_SESSION['nombreUsu']?></h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                 </button>
             </div>
             <div class="card card-body">
                                <!--Los datos del admin se mostrarán en modo readonly en el apartado de perfil -->
            <form action="" method="" name="formuDatosAdmin">
               <label for="idAdmin">ID</label>
               <input type="number" class="form-control" id="idAdmin" name="idAdmin" value="<?php echo $_SESSION['idUsu']?>" readonly>
<br>
               <label for="nombreAdmin">Nombre</label>
              <input type="text" class="form-control" id="nombreAdmin" name="nombreAdmin" value="<?php echo $_SESSION['nombreUsu']?>" readonly>
<br>
              <label for="emailAdmin">Correo</label>
               <input type="email" class="form-control" id="emailAdmin" name="emailAdmin" value="<?php echo $_SESSION['correoUsu']?>" readonly>
<br>
               <label for="telAdmin">Tel</label>
              <input type="tel" class="form-control" id="telAdmin" name="telAdmin" value="<?php echo $_SESSION['telefonoUsu']?>" readonly>

             
               <br>
               <br>

             </form>
             </div>
                                
         </div>
    </div>
 </div><!--Fin Modal Perfil -->







<div class="d-flex">
    <div class="sidebar sidebar-dark bg-dark">
        <ul class="list-unstyled">
            <li><a href="tareas.php"><i class="fa fa-fw fa-link"></i> Tareas</a></li>
            <li><a href="#"><i class="fa fa-fw fa-link"></i> Usuarios</a></li>
            <li><a href="participante.php"><i class="fa fa-fw fa-link"></i> Participante</a></li>
            <li><a href="roles.php"><i class="fa fa-fw fa-link"></i> Roles</a></li>
            <li><a href="areacateg.php"><i class="fa fa-fw fa-link"></i> Area / Categoría</a></li>
            <li><a href="estadousuario.php"><i class="fa fa-fw fa-link"></i> Estados Usuarios</a></li>


        </ul>
    </div>

    <div class="content p-4">
      <h2 class="mb-4">Usuarios</h2>

<!--Modal de Nuevo Usuario -->
      <div class="my-3">
        <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#nuevoUsuario" aria-expanded="false" >Nuevo Usuario</button>
      </div>

      <!--Los usuarios por defecto se registran activos y offline, por este motivo no existen esos campos en el formulario-->
      <div class="collapse my-3" id="nuevoUsuario" style="">
                <div class="card card-body">
                    <form name="formuNuevoUsuario" method="POST">
                      <div class="form-row">
                          <div class="col-md-2 mb-3">
                              <label for="nombreReg">Nombre</label>
                                  <input type="text" class="form-control" id="nombreReg" name="nombreReg" placeholder="Nombre" value="" required>
    
                          </div>
                          <div class="col-md-2 mb-3">
                              <label for="apellidoReg">Apellido</label>
                                  <input type="text" class="form-control" id="apellidoReg" name="apellidoReg" placeholder="Apellido" value="" required>
    
                          </div>
                          <div class="col-md-2 mb-3">
                              <label for="emailReg">Email</label>
                                  <input type="text" class="form-control" id="emailReg" name="emailReg" placeholder="Email" value="" required>
    
                          </div>
                          <div class="col-md-2 mb-3">
                              <label for="claveReg">Contraseña</label>
                                  <input type="password" class="form-control" id="claveReg" name="claveReg" placeholder="Contraseña" value="" required>
    
                          </div>
                          <div class="col-md-2 mb-3">
                              <label for="fdnReg">Fecha de nacimiento*</label>
                              <input type="date" class="form-control" id="fdnReg" name="fdnReg" required>
                            
                          </div>
             


                      </div>
                      <div class="form-row">
                          <div class="col-md-2 mb-3">
                              <label for="telReg">Teléfono</label>
                                  <input type="tel" class="form-control" id="telReg" name="telReg" placeholder="Teléfono">
    
                          </div>

                          <div class="col-md-2 mb-3">
                              <label for="generoReg">Género</label>
                              <input type="text" class="form-control" id="generoReg" name="generoReg" placeholder="Género">
                            
                          </div>

                           <div class="col-md-2 mb-3">
                              <label for="areaReg">Área</label>
                              <select class="form-control" id="areaReg" name="areaReg" required>
                                <?php

                                  $sqlAreaReg = "  
                                    SELECT *
                                      FROM area;

                                  ";

                                  $queryAreaReg = mysqli_query($conectar, $sqlAreaReg);

                                  while ($rowAreaReg = mysqli_fetch_assoc($queryAreaReg)){

                                      echo '<option value="'.$rowAreaReg['id_area'].'">'.$rowAreaReg['nombre_area'].'</opction>';

                                  }

                                ?>
                              </select>                      
                          </div>
                          <div class="col-md-2 mb-3">
                              <label for="rolReg">Rol</label>
                              <select class="form-control" id="rolReg" name="rolReg" required>
                                <?php

                                  $sqlRolReg = "  
                                    SELECT *
                                      FROM rol;

                                  ";

                                  $queryRolReg = mysqli_query($conectar, $sqlRolReg);

                                  while ($rowRolReg = mysqli_fetch_assoc($queryRolReg)){

                                    echo '<option value="'.$rowRolReg['id_rol'].'">'.$rowRolReg['nombre_rol'].'</opction>';

                                  }

                                ?>
                              </select>
                              
                          </div>

                      </div>
                      <div class="form-group mb-0">
                          <div class="form-check">
                              
                              <label  for="validadoReg">
                                  Validar usuario
                              </label>
                              <input  type="checkbox" value="si" id="validadoReg" name="validadoReg">
                        
                          </div>
                      </div>
                      <div class="form-group my-2">
                        <button class="btn btn-primary" type="submit" name="crearNuevoUsuario">Crear Usuario</button>
                      </div>
                  </form>
                </div>
            </div>
      





      <div class="card mb-4">
        <div class="card-body">
            <div id="example_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
              
              <div class="row">
                      <div class="col-sm-12">
                        <table id="example" class="table table-hover dataTable no-footer dtr-inline" cellspacing="0" width="100%" role="grid" aria-describedby="example_info" style="width: 100%;">
                <thead>
                <tr role="row">
                <th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 85.5px;" aria-sort="ascending" aria-label="Name: activate to sort column descending">Id</th>

                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 120.5px;" aria-label="Position: activate to sort column ascending">Nombre</th>

                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 120.5px;" aria-label="Position: activate to sort column ascending">Apellido</th>

                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 120.5px;" aria-label="Office: activate to sort column ascending">Email</th>

                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 93.5px;" aria-label="Salary: activate to sort column ascending">Teléfono</th>

                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 93.5px;" aria-label="Salary: activate to sort column ascending">Validación</th>

                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 93.5px;" aria-label="Salary: activate to sort column ascending">Activo</th>

                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 93.5px;" aria-label="Salary: activate to sort column ascending">Estado</th>

                <th class="actions sorting_disabled" rowspan="1" colspan="1" style="width: 100px;" aria-label="Actions">Acciones</th>
                </tr>
                </thead>


            <tbody>

                  <?php
                  #realizamos la consulta en la base de datos para ingresar la informacio'n de los usuarios en la tabla. Los JOIN son para poder ingresar los nombres de los IDs, los nombres de los estados de usuarios y el nombre de las 'areas en los SELECT del formulario de edici'on.
                    $sqlUsuarios = "  

                      SELECT *
                        FROM usuario
                          JOIN rol USING (id_rol)
                          JOIN estadousu USING (id_estado)
                          JOIN area USING (id_area);


                    ";

                    $queryUsuarios = mysqli_query($conectar, $sqlUsuarios);

                    while ($rowUsuarios = mysqli_fetch_assoc($queryUsuarios)){
                        #verificamos si el usuario esta' validado o no.

                        if($rowUsuarios['validado_usuario'] == 1){
                          $validado = '<div style="border-radius:50%; background-color:lightgreen; width: 20px; height:20px;"></div>';
                          $estadoValidacion = "checked"; #creamos la variable para poder llevar al formulario de edición de datos.
                        }else{
                          $validado = '<div style="border-radius:50%; background-color:crimson; width: 20px; height:20px;"></div>';
                          $estadoValidacion = ""; #creamos la variable para poder llevar al formulario de edición de datos.
                        } 


                        #verificamos si est'a activo o no


                        if($rowUsuarios['activo_usuario'] == 1){
                          $activo = '<div style="border-radius:50%; background-color:lightgreen; width: 20px; height:20px;"></div>';
                          $estadoActivo = "checked"; #creamos la variable para poder llevar al formulario de edición de datos.
                        }else{
                          $activo = '<div style="border-radius:50%; background-color:crimson; width: 20px; height:20px;"></div>';
                          $estadoActivo = ""; #creamos la variable para poder llevar al formulario de edición de datos.
                        } 

                          $estado = '<div style="border-radius:50%; background-color:'.$rowUsuarios['color_estado'].'; width: 20px; height:20px;" data-toggle="tooltip" title="'.$rowUsuarios['nombre_estado'].'"></div>';
                        
                        ?> 
                        <!-- Cortamos el PHP para poder meter el formulario como html y los campos dentro en php

                        #insertamos la tabla con sus variables dentro de un echo.

                        #asociamos el id del usuario al id del modal para que este sea 'unico.

                        #el bot'on de editar llevar'a el mismo id que el modal

                        #ingresamos un formulario dentro del modal para que aparezcan los datos almacenados en la bbdd y podamos editarlos.
                          #id disabled para que no se pueda editar
                          #se ingresa un input para cada campo.
                          #los campos validado y activo se marcan con un checkbox. Si el checkbox no est'a marcado al enviar el formulario quiere decir que no existe !isset. Por lo que se env'ia un false o 0.-->


<!-- MODAL CONTACTAR USUARIO -->

<div class="modal fade" id="modalEmail<?php echo $rowUsuarios['id_usuario'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalEmail">Constactar a <?php echo $rowUsuarios['nombre_usuario'];?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form name="fromuEnviarEmail" action="" method="POST" >
                  <div class="modal-body">
                     <div class="card mb-4">
                                      
                        <div class="card-body">
                                          
                          <div class="form-group">
                              <label for="correoContacto">Para</label>
                              <input type="email" class="form-control" id="correoContacto" name="correoContacto"  placeholder="Email" value="<?php echo $rowUsuarios['correo_usuario']; ?>" readonly>
                                <br>
                                                   <!--el id y el email son solo readonly -->
                              <label for="asuntoContacto" readonly>Asunto *</label>
                              <input type="text" class="form-control" id="asuntoContacto" name="asuntoContacto"  placeholder="Asunto" value="" requiered>
                                <br>  

                              <label for="mensajeContacto" readonly>Mensaje *</label>
                              <textarea class="form-control" name="mensajeContacto" id="mensajeContacto" cols="30" rows="10" style="resize: none" placeholder="Escribe tu mensaje" required></textarea>
                                <br>   


                          </div>

                        </div>
                    </div>
                  </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                        <button type="submit" class="btn btn-primary" name="enviarEmail">Enviar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>







<!--Modal cambio de datos -->
                  <div class="modal fade" id="modal<?php echo $rowUsuarios['id_usuario']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalCenterTitle">Datos de <?php echo $rowUsuarios['nombre_usuario'];?></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                
                                  
                                               

                              <form name="actualizarUser" action="" method="POST" >
                                <div class="modal-body">
                                   <div class="card mb-4">
                                      
                                      <div class="card-body">
                                          
                                              <div class="form-group">
                                                  <label for="identificador">ID</label>
                                                  <input type="number" class="form-control" id="identificador" name="identificador" aria-describedby="idHelp" placeholder="Id" value="<?php echo $rowUsuarios['id_usuario']; ?>" readonly>
                                                   <br>
                                                  
                                             
                                                  <label for="nombre">Nombre*</label>
                                                  <input type="text" class="form-control" id="nombre" name="nombre" aria-describedby="nombreHelp" placeholder="Nombre" value="<?php echo $rowUsuarios['nombre_usuario'];?>">
                                                   <br>
                                                  
                                              
                                                  <label for="apellido">Apellido*</label>
                                                  <input type="text" class="form-control" id="apellido" name="apellido" aria-describedby="apellidoHelp" placeholder="Apellido" value="<?php echo $rowUsuarios['apellido_usuario'];?>">
                                                   <br>
                                                  
                                              
                                                  <label for="email">Email*</label>
                                                  <input type="email" class="form-control" id="email" name="correo" aria-describedby="emailHelp" placeholder="Email" value="<?php echo $rowUsuarios['correo_usuario'];?>">
                                                   <br>    

                                                  <label for="fechaNacimiento">Fecha de Nacimiento*</label>
                                                  <input type="date" class="form-control" id="fdn" name="fdn" aria-describedby="fdnHelp" value="<?php echo $rowUsuarios['fdn_usuario'];?>">
                                                   <br>                                             
                                              
                                                  <label for="telefono">Teléfono</label>
                                                  <input type="tel" class="form-control" id="telefono" name="telefono" aria-describedby="telefonoHelp" placeholder="Teléfono" value="<?php echo $rowUsuarios['telefono_usuario'];?>">


                                              <br>
                                                   
                                                   <label for="genero">Género Usuario</label>
                                                  <input type="text" class="form-control" id="genero" name="genero" aria-describedby="generoHelp" placeholder="Teléfono" value="<?php echo $rowUsuarios['genero_usuario'];?>">
                                                   <br>

                                                   <label for="validado">Validado</label>
                                                  <input type="checkbox" class="form-control" id="validado" name="validado" aria-describedby="validadoHelp" value="si" <?php echo $estadoValidacion;?>>
                                                   <br>

                                                   <label for="activo">Activo</label>
                                                  <input type="checkbox" class="form-control" id="activo" name="activo" aria-describedby="activoHelp" value="si" <?php echo $estadoActivo;?>>
                                                   <br>

                                                    <label for="area">Area Usuario*</label>
                                                  <select class="form-control" id="area" name="area" aria-describedby="rolHelp">
                                                    <option value="<?php echo $rowUsuarios['id_area']; ?>">---<?php echo $rowUsuarios['nombre_area']; ?>---</option><!--El primer rol que aparece es el que el usuario tiene por defecto.-->

                                                    <?php #hacemos la query para ingresar los nombres de los roles en las options
                                                      $sqlArea = "
                                                        SELECT *
                                                          FROM area;

                                                      ";

                                                      $queryArea = mysqli_query($conectar, $sqlArea);
                                                      while($rowArea = mysqli_fetch_assoc($queryArea)) {

                                                        echo '<option value="'.$rowArea['id_area'].'">'.$rowArea['nombre_area'].'</option>';

                                                      }

                                                    ?>
                                                
                                                   </select>

            
                                                   <br>

                                                   <label for="rol">Rol Usuario*</label>
                                                  <select class="form-control" id="rol" name="rol" aria-describedby="rolHelp">
                                                    <option value="<?php echo $rowUsuarios['id_rol']; ?>">---<?php echo $rowUsuarios['nombre_rol']; ?>---</option><!--El primer rol que aparece es el que el usuario tiene por defecto.-->

                                                    <?php #hacemos la query para ingresar los nombres de los roles en las options
                                                      $sqlRoles = "
                                                        SELECT *
                                                          FROM rol;

                                                      ";

                                                      $queryRoles = mysqli_query($conectar, $sqlRoles);
                                                      while($rowRoles = mysqli_fetch_assoc($queryRoles)) {

                                                        echo '<option value="'.$rowRoles['id_rol'].'">'.$rowRoles['nombre_rol'].'</option>';

                                                      }                           

                                                    ?>
                                                
                                                   </select>

            
                                                   <br>


                                                   <label for="estadoUsu">Estado Usuario*</label>
                                                  <select class="form-control" id="estadoUsu" name="estadousu" aria-describedby="estadoUsuHelp">
                                                    <option value="<?php echo $rowUsuarios['id_estado']; ?>">---<?php echo $rowUsuarios['nombre_estado']; ?>---</option><!--El primer rol que aparece es el que el usuario tiene por defecto.-->
                                                    
                                                    <?php #hacemos la query para ingresar los nombres de los roles en las options
                                                      $sqlEstadoUsu = "
                                                        SELECT *
                                                          FROM estadousu;

                                                      ";

                                                      $queryEstadoUsu = mysqli_query($conectar, $sqlEstadoUsu);
                                                      while($rowEstadoUsu = mysqli_fetch_assoc($queryEstadoUsu)) {

                                                        echo '<option value="'.$rowEstadoUsu['id_estado'].'">'.$rowEstadoUsu['nombre_estado'].'</option>';

                                                      }





                                                    ?>

                                                  </select>
                                                   
                                                   <!--<label for="contrasena">Nueva Contraseña</label><br>
                                                 <input type="password" class="form-control" id="contrasena" name="contrasena" aria-describedby="claveHelp" placeholder="Contraseña" value="">-->
                                              </div>
                                              
                                          
                                      </div>
                                  </div>
                                </div>

                                  <div class="modal-footer">
                                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                      <button type="submit" class="btn btn-primary" name="cambiarDatos">Guardar</button>
                                  </div>
                              </form>
                                <form action="" name="modificaClave" method="POST">
                                                
                      <!--Modal cambio de Contraseña -->
                                                 <div class="collapse" id="claveUsu<?php echo $rowUsuarios['id_usuario']?>" style="">
                                                  
                                                    <div class="card card-body">
                                                      <!--Ingresamos un campo invisible para poder obtener el id del usuario-->
                                                      <input type="number" class="form-control" id="identificadorClave" name="identificadorClave" aria-describedby="idHelp" placeholder="Id" value="<?php echo $rowUsuarios['id_usuario']; ?>" readonly hidden>
                                                   <br>
                                                        <label for="ingresaClaveNueva">Ingresar Nueva Contraseña</label>
                                                        <input type="password" class="form-control" id="contrasena" name="contrasena" aria-describedby="claveHelp" placeholder="Contraseña" value="">
                                                        <br>
                                                        <label for="repiteClaveNueva">Repetir Nueva Contraseña</label>
                                                        <input type="password" class="form-control" id="repiteContrasena" name="repiteContrasena" aria-describedby="claveHelp" placeholder="Repite Contraseña" value="">
                                                        <br>
                                                        <div class="modal-footer">
                                                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                                          <button type="submit" class="btn btn-primary" name="cambiarClave">Guardar</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                   <button class="btn btn-danger" type="button" data-toggle="collapse" data-target="#claveUsu<?php echo $rowUsuarios['id_usuario']?>" aria-expanded="true" >Modificar Contraseña</button> 
                                                </div>
                                                </form>
                            </div>
                        </div>
                    </div>



<!-- MODAL ELIMINAR USUARIO -->

                    <div class="modal fade" id="modalEliminar<?php echo $rowUsuarios['id_usuario'];?>" tabindex="-1" role="dialog"  style="display: none;" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="modalEliminarTitle">Eliminar Usuario <?php echo $rowUsuarios['nombre_usuario'];?></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div class="modal-body">
                              <form action="" name="formuEliminarUsu" method="POST">

                                <p>¿Está seguro que desea eliminar al siguiente usuario?</p>
                                <label for="idEliminar">ID Usuario</label>
                                <input type="number" class="form-control" id="idEliminar" name="idEliminar" value="<?php echo $rowUsuarios['id_usuario'];?>">
                                <br>
                                <label for="nombreEliminar">ID Usuario</label>
                                <input type="text" class="form-control" id="nombreEliminar" name="nombreEliminar" value="<?php echo $rowUsuarios['nombre_usuario'];?>">
                                <br>
                                 <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                   <button  class="btn btn-danger" type="submit" name="eliminarUsuario">Eliminar</button>
                                 </div>
                              </form>
                                
                            </div>
                           
                        </div>
                    </div>
                </div>


                   
                    <?php #abrimos nuevamente para ingresar los dato de la bbdd
                      echo '
                        <tr role="row" class="odd">
                          <td tabindex="0" class="sorting_1">'.$rowUsuarios['id_usuario'].'</td>
                          <td>'.$rowUsuarios['nombre_usuario'].'</td>
                          <td>'.$rowUsuarios['apellido_usuario'].'</td>
                          <td>'.$rowUsuarios['correo_usuario'].'</td>
                          <td>'.$rowUsuarios['telefono_usuario'].'</td>
                          <td>'.$validado.'</td>
                          <td>'.$activo.'</td>
                          <td>'.$estado.'</td>
                          <td class=" actions">

                              <a href="#" class="btn btn-icon btn-pill btn-warning text-white" data-toggle="modal" data-target="#modalEmail'.$rowUsuarios['id_usuario'].'"><i class="fa fa-fw fa-envelope"></i></a>

                              <a href="#" class="btn btn-icon btn-pill btn-primary" data-toggle="modal" data-target="#modal'.$rowUsuarios['id_usuario'].'"><i class="fa fa-fw fa-edit"></i></a>

                              <a href="#" class="btn btn-icon btn-pill btn-danger" data-toggle="modal" data-target="#modalEliminar'.$rowUsuarios['id_usuario'].'"><i class="fa fa-fw fa-trash"></i></a>
                          </td>
                        </tr>
                        
                      ';
                    }

                  ?>


              </tbody>
            </table>


              



            <div id="example_processing" class="dataTables_processing card" style="display: none;">Procesando...</div></div></div><div class="row"><div class="col-sm-12 col-md-5"><div class="dataTables_info" id="example_info" role="status" aria-live="polite">Mostrando 1 al 25 de <?php echo mysqli_num_rows($queryUsuarios); #cuenta la cantidad de filas de la query ?> entradas</div></div><div class="col-sm-12 col-md-7"><div class="dataTables_paginate paging_simple_numbers" id="example_paginate"><ul class="pagination"><li class="paginate_button page-item previous disabled" id="example_previous"><a href="#" aria-controls="example" data-dt-idx="0" tabindex="0" class="page-link">Anterior</a></li><li class="paginate_button page-item active"><a href="#" aria-controls="example" data-dt-idx="1" tabindex="0" class="page-link">1</a></li><li class="paginate_button page-item "><a href="#" aria-controls="example" data-dt-idx="2" tabindex="0" class="page-link">2</a></li><li class="paginate_button page-item "><a href="#" aria-controls="example" data-dt-idx="3" tabindex="0" class="page-link">3</a></li><li class="paginate_button page-item next" id="example_next"><a href="#" aria-controls="example" data-dt-idx="4" tabindex="0" class="page-link">Siguiente</a></li></ul></div></div></div></div>
        </div>
    



    </div>

    </div><!--fin class content p-4-->
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/bootadmin.min.js"></script>
<script src="js/datatables.min.js"></script>
<script src="js/moment.min.js"></script>
<script src="js/fullcalendar.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>

 


        </script>
</body>
</html>