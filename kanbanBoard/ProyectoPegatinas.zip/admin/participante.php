<?php
  
  session_start();

  #su no existe variable de session lo lleva al index.
  if(!isset($_SESSION['idUsu'])) {

    header('Location: index.php');
  }

  #si no tiene permiso de administrador se redirecciona al index.
  if($_SESSION['rolUsu'] != 1){
    header('Location: index.php');
  }

  #si existe la session, iniciamos la conexión a la base de datos

  require '../includes/conexion.inc.php';




#==============================================================
#controlamos si hay un formulario enviado por POST
#==============================================================


if($_POST){


  #==================================
  # CREAR PARTICIPANTE
  #==================================

  if(isset($_POST['confirmarParticipante'])){

    $sqlNuevoParticipante = "  
      INSERT INTO participante
        VALUES (null,'".$_POST['nombreParticipante']."','".$_POST['tareaParticipante']."');

    ";

    $queryNuevoParticipante = mysqli_query($conectar, $sqlNuevoParticipante);

        echo '<div class="alert alert-success" role="alert">
                Participante creado correctamente.
            </div>';

  
  }

  #==================================
  # ELIMINAR PARTICIPANTE
  #==================================
  if(isset($_POST['modalEliminarParticipante'])){

    $sqlEliminarParticipante = "  
      DELETE FROM participante
          WHERE id_participante LIKE ".$_POST['idParticipanteEliminar'].";
    ";


    $queryEliminarParticipante = mysqli_query($conectar, $sqlEliminarParticipante);

       echo '<div class="alert alert-success" role="alert">
                Participante eliminado correctamente.
            </div>';
  }

}

?>


<!DOCTYPE html>
<html lang="en">
<head>



    <!--META-->
        <meta charset="UTF-8"> 
        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!--retrocompatible con microsoft edge-->
        <meta name="author" content=""><!-- quien hace la pagina web / desarrollador -->
        <meta name="copyright" content=""><!--derecho de copyright / derechos de explotacion / es a empresa-->
        <meta name="contact" content=""> <!--se especifica correo electronico de la persona que lleva el mantenimiento del sitio-->
        <meta name="description" content=""> <!--descripcion de la pagina web-->
        <meta name="keywords" content=""> <!--palabras clave por las que se indexan-->
        <meta name="robots" content="NoIndex, NoFollow"> <!--sustituye al robots.txt / el dia que se indexe cambia el content-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, shrink-to-fit=no">	

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/fontawesome-all.min.css">
    <link rel="stylesheet" href="css/bootadmin.min.css">
    <link rel="stylesheet" href="css/datatables.min.css">

    <link rel="icon" type="icon/png" href="fav.png">


    <title>Pegatinas | Área - Categoría</title>
</head>
<body class="bg-light">

<!--- MODAL CREAR PARTICIPANTE --->
         <?php 

                    if(isset($_POST['confirmarCategoria'])){

                         
                      ?>
                        <div class="modal fade show bg-dark" id="ingreaNuevoParticipante" tabindex="-1" role="dialog" aria-labelledby="ingreaNuevoParticipante" style="display: block;" aria-hidden="true">
                        
                        <div class="modal-dialog modal-dialog-centered" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="ingreaNuevoParticipante">Crear Participante en: </h5>
                                    <button type="button" class="close" data-dismiss="modal" id="cerrarModal1" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                    <div class="modal-body">
                      <form name="formuNuevoPArticipante" method="POST">
                  
                   
                            <div class="form-row">

                              <label for="tareaParticipante">Tarea</label>
                              <select class="form-control" id="tareaParticipante" name="tareaParticipante" aria-describedby="estadoUsuHelp">

                               <?php #hacemos la query para ingresar los nombres de los estados en las options
                                  $sqlTarea = "
                                    SELECT *
                                      FROM tarea
                                      WHERE id_categoria LIKE ".$_POST['categoriaParticipante'].";

                                  ";

                                    $queryTarea = mysqli_query($conectar, $sqlTarea);
                                    while($rowTarea = mysqli_fetch_assoc($queryTarea)) {

                                    echo '<option value="'.$rowTarea['id_tarea'].'">'.$rowTarea['nombre_tarea'].'</option>';

                                                      }

                                                    ?>
                         
                        </select>
                         <label for="nombreParticipante">Nombre</label>
                              <select class="form-control" id="nombreParticipante" name="nombreParticipante" aria-describedby="estadoUsuHelp">
                               <?php #hacemos la query para ingresar los nombres de los estados en las options
                                  $sqlUsuarioParticipante = "
                                    SELECT *
                                      FROM usuario
                                      WHERE id_area LIKE ".$_POST['categoriaParticipante'].";

                                  ";

                                    $queryUsuarioParticipante = mysqli_query($conectar, $sqlUsuarioParticipante);
                                    while($rowUsuarioParticipante = mysqli_fetch_assoc($queryUsuarioParticipante)) {

                                    echo '<option value="'.$rowUsuarioParticipante['id_usuario'].'">'.$rowUsuarioParticipante['nombre_usuario'].'</option>';

                                                      }

                                                    ?>
                         
                        </select>
                      </div>
                        

                      <div class="form-group my-2">
                        <button class="btn btn-primary" type="submit" data-toggle="modal" data-target="#ingreaNuevoParticipante" name="confirmarParticipante">Crear</button>
                      </div>
                  </form>
                </div>
                                </div>
                      
                            </div>
                        </div>
                    </div>


                      <?php


                    }



                  ?><!--- MODAL CREAR PARTICIPANTE --->



<nav class="navbar navbar-expand navbar-dark bg-primary">
    <a class="sidebar-toggle mr-3" href="#"><i class="fa fa-bars"></i></a>
    <a class="navbar-brand" href="main.php">Admin</a>

    <div class="navbar-collapse collapse">
        <ul class="navbar-nav ml-auto">
            
            <li class="nav-item dropdown">
                <a href="#" id="dd_user" class="nav-link dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> 
                	<!-- para que aparezca el nombre en la parte superior derecha -->
                	<?php echo $_SESSION['nombreUsu']?>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dd_user">
                    <a href="#" class="dropdown-item" data-toggle="modal" data-target="#modalPerfil">Perfil</a>

                    <a href="cerrar.php" class="dropdown-item">Cerrar Sesión</a>
                </div>
            </li>
        </ul>
    </div>

</nav>
<!--Modal Perfil -->
               
 <div class="modal fade" id="modalPerfil" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Datos de <?php echo $_SESSION['nombreUsu']?></h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                 </button>
             </div>
             <div class="card card-body">
                                <!--Los datos del admin se mostrarán en modo readonly en el apartado de perfil -->
            <form action="" method="" name="formuDatosAdmin">
               <label for="idAdmin">ID</label>
               <input type="number" class="form-control" id="idAdmin" name="idAdmin" value="<?php echo $_SESSION['idUsu']?>" readonly>
<br>
               <label for="nombreAdmin">Nombre</label>
              <input type="text" class="form-control" id="nombreAdmin" name="nombreAdmin" value="<?php echo $_SESSION['nombreUsu']?>" readonly>
<br>
              <label for="emailAdmin">Correo</label>
               <input type="email" class="form-control" id="emailAdmin" name="emailAdmin" value="<?php echo $_SESSION['correoUsu']?>" readonly>
<br>
               <label for="telAdmin">Tel</label>
              <input type="tel" class="form-control" id="telAdmin" name="telAdmin" value="<?php echo $_SESSION['telefonoUsu']?>" readonly>

             
               <br>
               <br>

             </form>
             </div>
                                
         </div>
    </div>
 </div><!--Fin Modal Perfil -->


<div class="d-flex">
    <div class="sidebar sidebar-dark bg-dark">
        <ul class="list-unstyled">
            <li><a href="tareas.php"><i class="fa fa-fw fa-link"></i> Tareas</a></li>
            <li><a href="usuarios.php"><i class="fa fa-fw fa-link"></i> Usuarios</a></li>
            <li><a href="#"><i class="fa fa-fw fa-link"></i> Participante</a></li>
            <li><a href="roles.php"><i class="fa fa-fw fa-link"></i> Roles</a></li>
            <li><a href="areacateg.php"><i class="fa fa-fw fa-link"></i> Area / Categoría</a></li>
            <li><a href="estadousuario.php"><i class="fa fa-fw fa-link"></i> Estados Usuarios</a></li>


        </ul>
    </div>

    <div class="content p-4">
      <h2 class="mb-4">Participante</h2>




      	 <!--Modal de Nuevo PARTICIPANTE Drop-->
      	<div class="my-3">
        	<button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#nuevoParticipante" aria-expanded="false" >Nuevo Participante</button>
      	</div>


      <div class="collapse my-3" id="nuevoParticipante" style="">
                <div class="card card-body">
                    <form name="formuNuevoParticipante" method="POST">
                      <!--Mostramos todas las categorias disponibles y cuardamos el valor del radio -->
                        <p><strong>Seleccionar Categoría</strong></p> 
                   
                        <?php
                          
                          $sqlCategoriaParticipante = "  

                            SELECT *
                              FROM categoria
                              GROUP BY nombre_categoria;
                              
                          ";

                          $queryCategoriaParticipante = mysqli_query($conectar, $sqlCategoriaParticipante);

                          while ($rowCategoriaParticipante = mysqli_fetch_assoc($queryCategoriaParticipante)){

                            echo '

                            <input type="radio" id="categoriaParticipante" name="categoriaParticipante" value='.$rowCategoriaParticipante['id_categoria'].' required>
                              <label for="'.$rowCategoriaParticipante['nombre_categoria'].'" style="margin-right:50px;">'.$rowCategoriaParticipante['nombre_categoria'].'</label>



                            ';
                            }
                            ?>
                        
                        

                      <div class="form-group my-2">
                        <button class="btn btn-primary" type="submit" data-toggle="modal" data-target="#ingreaNuevoParticipante" name="confirmarCategoria">Confirmar</button>
                      </div>



                   </form>

    

                </div>
            </div>



           






      <div class="card mb-4">
        <div class="card-body">
            <div id="example_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
              
              <div class="row">
                      <div class="col-sm-12">
                        <table id="example" class="table table-hover dataTable no-footer dtr-inline" cellspacing="0" width="100%" role="grid" aria-describedby="example_info" style="width: 100%;">
                <thead>
                <tr role="row">
                <th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 85.5px;" aria-sort="ascending" aria-label="Name: activate to sort column descending">Id Participante</th>

                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 120.5px;" aria-label="Position: activate to sort column ascending">Id  Usuario</th>

                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 120.5px;" aria-label="Position: activate to sort column ascending">Usuario</th>

                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 85.5px;" aria-label="Position: activate to sort column ascending">Id Tarea</th>
                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 120.5px;" aria-label="Position: activate to sort column ascending">Tarea</th>

                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 120.5px;" aria-label="Position: activate to sort column ascending">Categoría</th>

                
                <th class="actions sorting_disabled" rowspan="1" colspan="1" style="width: 100px;" aria-label="Actions">Acciones</th>
                </tr>
                </thead>


            <tbody>

            <!--En esta seccion solo se pueden crear o eliminar los campos -->

               <?php
                  #realizamos la consulta en la base de datos para ingresar la informacio'n de las tareas en la tabla. Los JOIN son para poder ingresar los nombres, los  estados y las categorías.
                    $sqlParticipante = "  

                      SELECT *
                        FROM participante
                        JOIN usuario USING (id_usuario)
                        JOIN tarea USING (id_tarea)
                        JOIN categoria USING (id_categoria);
                         
                    ";

                    $queryParticipante = mysqli_query($conectar, $sqlParticipante);

                    while ($rowParticipante = mysqli_fetch_assoc($queryParticipante)){
                         
                      ?>


    


                      <!-- Modal Eliminar Participante -->
                    <div class="modal fade" id="eliminarParticipante<?php echo $rowParticipante['id_participante'];?>" tabindex="-1" role="dialog"  style="display: none;" aria-hidden="true">
                      <div class="modal-dialog modal-dialog-centered" role="document">
                          <div class="modal-content">
                              <div class="modal-header">
                                  <h5 class="modal-title" id="eliminarRol">Eliminar Participante: <?php echo $rowParticipante['id_participante'];?></h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">×</span>
                                  </button>
                              </div>
                              <div class="modal-body">
                                <form action="" name="formuEliminarParticipante" method="POST">

                                  <p>¿Está seguro que desea eliminar al siguiente Participante?</p>
                                  <label for="idParticipanteEliminar">ID Participante</label>
                                  <input type="number" class="form-control" id="idParticipanteEliminar" name="idParticipanteEliminar" value="<?php echo $rowParticipante['id_participante'];?>">
                                  <br>
                              
                                   <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                     <button  class="btn btn-danger" type="submit" name="modalEliminarParticipante">Eliminar</button>
                                   </div>
                                </form>
                                  
                              </div>
                             
                                </div>
                            </div>
                      </div>
                  



                      <?php

                         echo '
                        <tr role="row" class="odd">
                          <td tabindex="0" class="sorting_1">'.$rowParticipante['id_participante'].'</td>

                          <td>'.$rowParticipante['id_usuario'].'</td>
                          <td>'.$rowParticipante['nombre_usuario'].'</td>
                          <td>'.$rowParticipante['id_tarea'].'</td>
                          <td>'.$rowParticipante['nombre_tarea'].'</td>
                          <td>'.$rowParticipante['nombre_categoria'].'</td>
                          <td class=" actions">


                              <a href="#" class="btn btn-icon btn-pill btn-danger" data-toggle="modal" data-target="#eliminarParticipante'.$rowParticipante['id_participante'].'"><i class="fa fa-fw fa-trash"></i></a>
                          </td>
                        </tr>
                        
                      ';
                    }

                      ?>
                 


              </tbody>
            </table>


              



            <div id="example_processing" class="dataTables_processing card" style="display: none; ">Procesando...</div></div></div><div class="row pt-3" style="border-top: 1px solid rgba(0,0,0,0.2);"><div class="col-sm-12 col-md-5"><div class="dataTables_info" id="example_info" role="status" aria-live="polite" >Mostrando 1 al 25 de <?php echo mysqli_num_rows($queryParticipante); #cuenta la cantidad de filas de la query ?> entradas</div></div><div class="col-sm-12 col-md-7"><div class="dataTables_paginate paging_simple_numbers" id="example_paginate"><ul class="pagination"><li class="paginate_button page-item previous disabled" id="example_previous"><a href="#" aria-controls="example" data-dt-idx="0" tabindex="0" class="page-link">Anterior</a></li><li class="paginate_button page-item active"><a href="#" aria-controls="example" data-dt-idx="1" tabindex="0" class="page-link">1</a></li><li class="paginate_button page-item "><a href="#" aria-controls="example" data-dt-idx="2" tabindex="0" class="page-link">2</a></li><li class="paginate_button page-item "><a href="#" aria-controls="example" data-dt-idx="3" tabindex="0" class="page-link">3</a></li><li class="paginate_button page-item next" id="example_next"><a href="#" aria-controls="example" data-dt-idx="4" tabindex="0" class="page-link">Siguiente</a></li></ul></div></div></div></div>
        </div>
    



    </div>


     </div>
 </div>


 <script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/bootadmin.min.js"></script>
<script src="js/datatables.min.js"></script>
<script src="js/moment.min.js"></script>
<script src="js/fullcalendar.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>

<script>
  $('#cerrarModal1').click(function(){

    window.location = "participante.php";


  });
</script>

 


        </script>
</body>
</html>