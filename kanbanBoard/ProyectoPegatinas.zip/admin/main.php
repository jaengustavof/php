<?php
	
	session_start();

	#su no existe variable de session lo lleva al index.
	if(!isset($_SESSION['idUsu'])) {

		header('Location: index.php');
	}

	if($_SESSION['rolUsu'] != 1){
		header('Location: index.php');
	}

	#si existe la session, iniciamos la conexión a la base de datos

	require '../includes/conexion.inc.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>



 <!--META-->
        <meta charset="UTF-8"> 
        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!--retrocompatible con microsoft edge-->
        <meta name="author" content=""><!-- quien hace la pagina web / desarrollador -->
        <meta name="copyright" content=""><!--derecho de copyright / derechos de explotacion / es a empresa-->
        <meta name="contact" content=""> <!--se especifica correo electronico de la persona que lleva el mantenimiento del sitio-->
        <meta name="description" content=""> <!--descripcion de la pagina web-->
        <meta name="keywords" content=""> <!--palabras clave por las que se indexan-->
        <meta name="robots" content="NoIndex, NoFollow"> <!--sustituye al robots.txt / el dia que se indexe cambia el content-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, shrink-to-fit=no">	

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/fontawesome-all.min.css">
    <link rel="stylesheet" href="css/bootadmin.min.css">

    <link rel="stylesheet" href="../vendor/ChartJs/css/Chart.min.css">

    <link rel="icon" type="icon/png" href="fav.png">

    <title>Pegatinas | Main</title>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand navbar-dark bg-primary">
    <a class="sidebar-toggle mr-3" href="#"><i class="fa fa-bars"></i></a>
    <a class="navbar-brand" href="main.php">Pegatinas</a>

    <div class="navbar-collapse collapse">
        <ul class="navbar-nav ml-auto">
            
            <li class="nav-item dropdown">
                <a href="#" id="dd_user" class="nav-link dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> 
                	<!-- para que aparezca el nombre en la parte superior derecha -->
                	<?php echo $_SESSION['nombreUsu']?>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dd_user">
                    <a href="#" class="dropdown-item" data-toggle="modal" data-target="#modalPerfil">Perfil</a>

                    <a href="cerrar.php" class="dropdown-item">Cerrar Sesión</a>
                </div>
            </li>
        </ul>
    </div>

</nav>
<!--Modal Perfil -->
               
 <div class="modal fade" id="modalPerfil" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Datos de <?php echo $_SESSION['nombreUsu']?></h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                 </button>
             </div>
             <div class="card card-body">
                                <!--Los datos del admin se mostrarán en modo readonly en el apartado de perfil -->
            <form action="" method="" name="formuDatosAdmin">
               <label for="nombreReg">ID</label>
               <input type="number" class="form-control" id="idAdmin" name="idAdmin" value="<?php echo $_SESSION['idUsu']?>" readonly>
<br>
               <label for="nombreReg">Nombre</label>
              <input type="text" class="form-control" id="nombreAdmin" name="nombreAdmin" value="<?php echo $_SESSION['nombreUsu']?>" readonly>
<br>
              <label for="nombreReg">Correo</label>
               <input type="email" class="form-control" id="emailAdmin" name="emailAdmin" value="<?php echo $_SESSION['correoUsu']?>" readonly>
<br>
               <label for="nombreReg">Tel</label>
              <input type="tel" class="form-control" id="telAdmin" name="telAdmin" value="<?php echo $_SESSION['telefonoUsu']?>" readonly>

 
               <br>

             </form>
             </div>
                                
         </div>
    </div>
 </div><!--Fin Modal Perfil -->


<div class="d-flex">
    <div class="sidebar sidebar-dark bg-dark">
        <ul class="list-unstyled">
            <li><a href="tareas.php"><i class="fa fa-fw fa-link"></i> Tareas</a></li>
            <li><a href="usuarios.php"><i class="fa fa-fw fa-link"></i> Usuarios</a></li>
            <li><a href="participante.php"><i class="fa fa-fw fa-link"></i> Participante</a></li>
            <li><a href="roles.php"><i class="fa fa-fw fa-link"></i> Roles</a></li>
            <li><a href="areacateg.php"><i class="fa fa-fw fa-link"></i> Area / Categoría</a></li>
            <li><a href="estadousuario.php"><i class="fa fa-fw fa-link"></i> Estados Usuarios</a></li>


        </ul>
    </div>

    <div class="content p-4">
        <h2 class="mb-4">Dashboard</h2>
        <!--Inicio Dashboard-->
        <div class="row"><!--Primer Columna Dashboard-->
	        <div class="col-md">
			   <div class="d-flex border">
			        <div class="bg-dark text-light p-4">
			            <div class="d-flex align-items-center h-100">
			               <i class="fa fa-3x fa-fw fa-clock"></i>
			            </div>
			        </div>
			        <div class="flex-grow-1 bg-white p-4">
			            <p class="text-uppercase text-secondary mb-0">Tiempo Promedio por tarea</p>
			            <h3 class="font-weight-bold mb-0">
			            	<?php
			            	#realizamos la consulta para obtener la fecha de creacion y de actualizacion de las tareas terminadas.
			            		$sqlMediaTarea = " 

			            			SELECT fdc_tarea, fda_tarea
			            				FROM tarea
			            				WHERE id_estado LIKE 3;

			            		";

			            		$queryMediaTarea = mysqli_query($conectar, $sqlMediaTarea);

			            		$contadorTareas = 0; #cuenta cuantas tareas
			            		$tiempoTotal = 0; #acumula los tiempos de las taresas
			            		while ($rowMediaTarea = mysqli_fetch_assoc($queryMediaTarea)) {

			            			#utlilziamos la clase de PHP DateTime para asignar las fechas.
			            			$fechaInicio = new DateTime($rowMediaTarea['fdc_tarea']);
			            			$fechaFin = new DateTIme($rowMediaTarea['fda_tarea']);
			            			$diff = $fechaInicio->diff($fechaFin);
			            			#obtenemos la diferencia en días
			            			$tiempoTarea = $diff->days;

			            			//echo $tiempoTarea." Días";
			            			#Sumamos todos los dias y aumentamos en 1 el contador de tareas.
			            			$tiempoTotal += $tiempoTarea;
			            			$contadorTareas++;


			            		}

			            		$total = ($tiempoTotal/$contadorTareas);
			            		echo round($total)." días";
			            		#redondeamos la cantidad de días.


			            	?>

			            </h3>
			        </div>
			   </div>
			</div>
			<div class="col-md">
			   <div class="d-flex border">
			        <div class="bg-danger text-light p-4">
			            <div class="d-flex align-items-center h-100">
			               <i class="fa fa-3x fa-fw fa-hourglass"></i>
			            </div>
			        </div>
			        <div class="flex-grow-1 bg-white p-4">
			            <p class="text-uppercase text-secondary mb-0">Tareas Pendientes</p>
			            <h3 class="font-weight-bold mb-0">
			            	<?php
			            	#realizamos la consulta de todas las tareas pendientes (con estado 1)
			            	$sqlTareasPendiente = "  
			            		SELECT COUNT(*) AS tareas_pendiente
			            			FROM tarea
			            			WHERE id_estado LIKE 1;

			            	";

			            	$queryTareasPendiente = mysqli_query($conectar, $sqlTareasPendiente);

			            	while ($rowTareasPendiente = mysqli_fetch_assoc($queryTareasPendiente)){
			            		echo $rowTareasPendiente['tareas_pendiente'];
			            	}

			            ?>

			            </h3>
			        </div>
			   </div>
			</div>
			<div class="col-md">
			   <div class="d-flex border">
			        <div class="bg-warning text-light p-4">
			            <div class="d-flex align-items-center h-100">
			               <i class="fa fa-3x fa-fw fa-cog"></i>

			            </div>
			        </div>
			        <div class="flex-grow-1 bg-white p-4">
			            <p class="text-uppercase text-secondary mb-0">Tareas en Proceso</p>
			            <h3 class="font-weight-bold mb-0"><?php
			            #realizamos la consulta de todas las tareas en proceso (con estado 2)
			            	$sqlTareasProceso = "  
			            		SELECT COUNT(*) AS tareas_proceso
			            			FROM tarea
			            			WHERE id_estado LIKE 2;

			            	";

			            	$queryTareasProceso = mysqli_query($conectar, $sqlTareasProceso);

			            	while ($rowTareasProceso = mysqli_fetch_assoc($queryTareasProceso)){
			            		echo $rowTareasProceso['tareas_proceso'];
			            	}

			            ?></h3>
			        </div>
			   </div>
			</div>
			<div class="col-md">
			   <div class="d-flex border">
			        <div class="bg-success text-light p-4">
			            <div class="d-flex align-items-center h-100">
			               <i class="fa fa-3x fa-fw fa-check-circle"></i>
			            </div>
			        </div>
			        <div class="flex-grow-1 bg-white p-4">
			            <p class="text-uppercase text-secondary mb-0">Tareas Finalizadas</p>
			            <h3 class="font-weight-bold mb-0"><?php
			            #realizamos la consulta de todas las tareas finalizadas (con estado 3)
			            	$sqlTareasFinalizadas = "  
			            		SELECT COUNT(*) AS tareas_finalizada
			            			FROM tarea
			            			WHERE id_estado LIKE 3;

			            	";

			            	$queryTareasFinalizadas = mysqli_query($conectar, $sqlTareasFinalizadas);

			            	while ($rowTareasFinalizadas = mysqli_fetch_assoc($queryTareasFinalizadas)){
			            		echo $rowTareasFinalizadas['tareas_finalizada'];
			            	}

			            ?>
			            	
			            </h3>
			        </div>
			   </div>
			</div>
		</div><!--Fin Primer Columna Dashboard-->

		<div class="row my-4"><!--Segunda Columna Dashboard-->
	        <div class="col-md">
			   <div class="d-flex border">
			        <div class="bg-primary text-light p-4">
			            <div class="d-flex align-items-center h-100">
			               <i class="fa fa-3x fa-fw fa-tasks"></i>
			            </div>
			        </div>
			        <div class="flex-grow-1 bg-white p-4">
			            <p class="text-uppercase text-secondary mb-0">Total tareas del mes</p>
			            <h3 class="font-weight-bold mb-0"><?php
			            #Consultamos todas las tareas del mes en curso. MONTH(fdc_tarea) -> obtiene el mes de la tarea y lo compara con el mes en curso MONTH(CURDATE()).

			            	$sqlTareasDelMes = "   

			            		SELECT COUNT(*) AS totalTareas_mes
									FROM tarea
								    WHERE MONTH(fdc_tarea) LIKE MONTH(CURDATE());
			            	";

			            	$queryTareasDelMes = mysqli_query($conectar, $sqlTareasDelMes);

			            	while($rowTareasDelMes = mysqli_fetch_assoc($queryTareasDelMes)){

			            		echo $rowTareasDelMes['totalTareas_mes'];
			            	}




			            ?></h3>
			        </div>
			   </div>
			</div>
			<div class="col-md">
			   <div class="d-flex border">
			        <div class="bg-primary text-light p-4">
			            <div class="d-flex align-items-center h-100">
			               <i class="fa fa-3x fa-fw fa-clock"></i>
			            </div>
			        </div>
			        <div class="flex-grow-1 bg-white p-4">
			            <p class="text-uppercase text-secondary mb-0">Usuarios en Actividad</p>
			            <h3 class="font-weight-bold mb-0">
			            	<?php
			            	#utlizamos un alias para poder sacar su valor en el while.
			            		$sqlOnline = "  
			            			SELECT COUNT(id_usuario) AS online_usuario
			            				FROM usuario
			            				WHERE id_estado LIKE 1
			            					AND id_rol NOT LIKE 1;

			            		";

			            		$queryOnline = mysqli_query($conectar, $sqlOnline);

			            		while($rowOnline = mysqli_fetch_assoc($queryOnline)){
			            			echo $rowOnline['online_usuario'];

			            		}

			            	 ?>

			            </h3>
			        </div>
			   </div>
			</div>
			<div class="col-md">
			   <div class="d-flex border">
			        <div class="bg-primary text-light p-4">
			            <div class="d-flex align-items-center h-100">
			               <i class="fa fa-3x fa-fw fa-users"></i>
			            </div>
			        </div>
			        <div class="flex-grow-1 bg-white p-4">
			            <p class="text-uppercase text-secondary mb-0">Usuarios Registrados</p>
			            <h3 class="font-weight-bold mb-0"><?php
			            	#obtenemos todos los usuarios que no sean admin
			            	$sqlUsuariosRegistrados = "  
			            		SELECT COUNT(*) AS usuarios_registrados
			            			FROM usuario
			            			WHERE id_rol NOT LIKE 1;

			            	";

			            	$queryUsuariosRegistrados = mysqli_query($conectar, $sqlUsuariosRegistrados);

			            	while($rowUsuariosRegistrador = mysqli_fetch_assoc($queryUsuariosRegistrados)){
			            		echo $rowUsuariosRegistrador['usuarios_registrados'];
			            	}

			            ?>
			            	
			            </h3>
			        </div>
			   </div>
			</div>
			<div class="col-md">
			   <div class="d-flex border">
			        <div class="bg-primary text-light p-4">
			            <div class="d-flex align-items-center h-100">
			               <i class="fa fa-3x fa-fw fa-info-circle"></i>
			            </div>
			        </div>
			        <div class="flex-grow-1 bg-white p-4">
			            <p class="text-uppercase text-secondary mb-0">Roles (Admin / Usuarios)</p>
			            <h3 class="font-weight-bold mb-0"><?php
			            #realizamos dos consultas. Una para obtener el n'umero de usuarios Admin y la segunda para los usuarios sin privilegios de administrador.
			            	$sqlRolAdmin = "  
			            		SELECT COUNT(id_rol) AS tot_admin
			            			FROM rol
			            			JOIN usuario USING (id_rol)
			            			WHERE id_rol LIKE 1;

			            	";

			            	$sqlRolUsuario = "  
			            		SELECT nombre_rol, COUNT(id_rol) AS tot_usu
			            			FROM rol
			            			JOIN usuario USING (id_rol)
			            			WHERE id_rol LIKE 2;

			            	";

			            	$queryRolAdmin = mysqli_query($conectar, $sqlRolAdmin);
			            	$queryRolUsuario = mysqli_query($conectar, $sqlRolUsuario);


			            	while($rowRolAdmin = mysqli_fetch_assoc($queryRolAdmin)) {

			            		echo $rowRolAdmin['tot_admin']." / ";
			            	}

			            	while($rowRolUsuario= mysqli_fetch_assoc($queryRolUsuario)) {

			            		echo $rowRolUsuario['tot_usu'];
			            	}



			            ?></h3>
			        </div>
			   </div>
			</div>
		</div><!--Fin Segunda Columna Dashboard-->


        <div class="card my-4">
            <div class="card-body">
      

          <div class="row py-2"><!--Inicio Chart-->
	        <div class="col-md-6 py-1">
	        	
	            <div class="card">
	            	<h4 class="p-2">Usuarios por Categoría</h4>
	                <div class="card-body">
	                    <canvas id="chDonut1"></canvas>
	                </div>
	            </div>
	        </div>
	        <div class="col-md-6 py-1">
	        	
	            <div class="card">
	            	<h4 class="p-2">Tareas por Área</h4>
	                <div class="card-body">
	                    <canvas id="chDonut2"></canvas>
	                </div>
	            </div>
	        </div>
	        
	    </div><!--Fin Chart-->


            </div>
        </div><!--FIN DASHBOARD-->

    </div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/bootadmin.min.js"></script>

  <script type="text/javascript" src="../vendor/jquery/jquery-3.5.1.min.js"></script> 
  <script type="text/javascript" src="../vendor/ChartJs/js/Chart.min.js">
 	
 </script><!--Chart.js-->
  <script type="text/javascript" src="../vendor/ChartJs/js/utils.js">
 	
 </script><!--Chart.js-->

  <!--ASI SE IMPLMENTA JQUERY --><!-- JQUERY UI DEBE TENER JQUERY INSTALADO-->
  
       
        
        <script type="text/javascript" src="../assets/js/script.js"></script>

        <noscript>Debe habilitar JavaScript</noscript>

        <script type="text/javascript">
 

/* 2 donut charts */
var donutOptions = {
  cutoutPercentage: 85, 
  legend: {position:'bottom', padding:5, labels: {pointStyle:'circle', usePointStyle:true}}
};

// donut 1
var areas = [];
var colorArea = [];
var cantidadArea = [];
$.ajax({

                url: 'https://jaenwebdesign.com/PHP/Proyecto/ajax/graficoUno.app.php',
                type: 'GET',/*peticion en GET para que puedan ser utlizadas en m'ovil*/
                dataType: 'JSON',
                success: function(tareas){


                  for(let i = 0; i < tareas.length; i++ ){
                        //console.log(i);
                       areas.push(tareas[i].nombre_area);
                       colorArea.push(tareas[i].color_area);
                       cantidadArea.push(tareas[i].cuenta)

                    }
                
              //  console.log(cantidadArea);
                  var chDonutData1 = {

                        labels: areas,
                        datasets: [
                          {
                            backgroundColor: colorArea,
                            borderWidth: 0,
                            data: cantidadArea
                          }
                        ]
                    };

                    var chDonut1 = document.getElementById("chDonut1");
                    if (chDonut1) {
                      new Chart(chDonut1, {
                          type: 'pie',
                          data: chDonutData1,
                          options: donutOptions
                      });
                    }

        

                },
                error: function(){
                    $("#mensaje").html('Error NO es posible encontrar el archivo de la petición ajax.');
                }

            });


// donut 2
var categorias = [];
var coloCategorias = [];
var cantidadCateg = [];

$.ajax({
              
                url: 'https://jaenwebdesign.com/PHP/Proyecto/ajax/graficoDos.app.php',
                type: 'GET',/*peticion en GET para que puedan ser utlizadas en m'ovil*/
                dataType: 'JSON',
                success: function(tareas){

                  for(let i = 0; i < tareas.length; i++ ){
                        //console.log(i);
                       categorias.push(tareas[i].nombre_categoria);
                       coloCategorias.push(tareas[i].color_categoria);
                       cantidadCateg.push(tareas[i].cuenta)

                    }
                
            
                    var chDonutData2 = {
                        labels: categorias,
                        datasets: [
                          {
                            backgroundColor: coloCategorias,
                            borderWidth: 0,
                            data: cantidadCateg
                          }
                        ]
                    };
                    var chDonut2 = document.getElementById("chDonut2");
                    if (chDonut2) {
                      new Chart(chDonut2, {
                          type: 'pie',
                          data: chDonutData2,
                          options: donutOptions
                      });
                    }
        

                },
                error: function(){
                    $("#mensaje").html('Error NO es posible encontrar el archivo de la petición ajax.');
                }

            });




        </script>
</body>
</html>