<?php
  
  session_start();

  #su no existe variable de session lo lleva al index.
  if(!isset($_SESSION['idUsu'])) {

    header('Location: index.php');
  }

  #si no tiene permiso de administrador se redirecciona al index.
  if($_SESSION['rolUsu'] != 1){
    header('Location: index.php');
  }

  #si existe la session, iniciamos la conexión a la base de datos

  require '../includes/conexion.inc.php';



  if($_POST){


  	#=========================================
    #CREAR NUEVO ESTADO
    #=========================================
    if(isset($_POST['crearNuevoEstado'])){

      if((isset($_POST['nombreNuevoEstado']) && !empty($_POST['nombreNuevoEstado'])) && (isset($_POST['colorNuevoEstado']) && !empty($_POST['colorNuevoEstado']))){

        $sqlCrearEstado = "  

          INSERT INTO estadousu
            VALUES (null,'".$_POST['nombreNuevoEstado']."', '".$_POST['colorNuevoEstado']."');

        ";

        $queryCrearEstado = mysqli_query($conectar, $sqlCrearEstado);

         echo '<div class="alert alert-success" role="alert">
                Estado Creado correctamente.
            </div>';


      }else{
        echo '<div class="alert alert-danger" role="alert">
                Todos los campos son obligatorios.
            </div>';
      }
    }




    #=========================================
    #EDITAR ESTADO
    #=========================================

    if(isset($_POST['modificaEstado'])){


      if((isset($_POST['idModificarEstado']) && !empty($_POST['idModificarEstado'])) && (isset($_POST['nombreModificarEstado']) && !empty($_POST['nombreModificarEstado'])) && (isset($_POST['colorModificarEstado']) && !empty($_POST['colorModificarEstado']))) {

          $sqlModificaEstado = "  

          UPDATE estadousu
            SET nombre_estado = '".$_POST['nombreModificarEstado']."',
                color_estado = '".$_POST['colorModificarEstado']."'
                WHERE id_estado LIKE ".$_POST['idModificarEstado'].";


          ";

          $queryModificaEstado = mysqli_query($conectar, $sqlModificaEstado);

           echo '<div class="alert alert-success" role="alert">
                Estado modificado correctamente.
            </div>';

      }else{
        echo '<div class="alert alert-danger" role="alert">
                Todos los campos son obligatorios.
            </div>';
      }

    }



  	#=========================================
    #ELIMINAR ROL
    #=========================================

    if(isset($_POST['modalEliminarEstado'])){

       $sqlEliminaEstado = "  
        DELETE FROM estadousu
          WHERE id_estado LIKE ".$_POST['idEstadoEliminar'].";
      ";


      $queryEliminaEstado = mysqli_query($conectar, $sqlEliminaEstado);

      echo '<div class="alert alert-success" role="alert">
                Estado eliminado correctamente.
            </div>';
    }else{
        echo '<div class="alert alert-danger" role="alert">
                Todos los campos son obligatorios.
            </div>';
      }

    


  }

?>


<!DOCTYPE html>
<html lang="en">
<head>



    <!--META-->
        <meta charset="UTF-8"> 
        <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!--retrocompatible con microsoft edge-->
        <meta name="author" content=""><!-- quien hace la pagina web / desarrollador -->
        <meta name="copyright" content=""><!--derecho de copyright / derechos de explotacion / es a empresa-->
        <meta name="contact" content=""> <!--se especifica correo electronico de la persona que lleva el mantenimiento del sitio-->
        <meta name="description" content=""> <!--descripcion de la pagina web-->
        <meta name="keywords" content=""> <!--palabras clave por las que se indexan-->
        <meta name="robots" content="NoIndex, NoFollow"> <!--sustituye al robots.txt / el dia que se indexe cambia el content-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, shrink-to-fit=no">	

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/fontawesome-all.min.css">
    <link rel="stylesheet" href="css/bootadmin.min.css">
    <link rel="stylesheet" href="css/datatables.min.css">

    <link rel="icon" type="icon/png" href="fav.png">


    <title>Pegatinas | Estados Usarios</title>
</head>
<body class="bg-light">



<nav class="navbar navbar-expand navbar-dark bg-primary">
    <a class="sidebar-toggle mr-3" href="#"><i class="fa fa-bars"></i></a>
    <a class="navbar-brand" href="main.php">Pegatinas</a>

    <div class="navbar-collapse collapse">
        <ul class="navbar-nav ml-auto">
            
            <li class="nav-item dropdown">
                <a href="#" id="dd_user" class="nav-link dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> 
                	<!-- para que aparezca el nombre en la parte superior derecha -->
                	<?php echo $_SESSION['nombreUsu']?>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dd_user">
                    <a href="#" class="dropdown-item" data-toggle="modal" data-target="#modalPerfil">Perfil</a>

                    <a href="cerrar.php" class="dropdown-item">Cerrar Sesión</a>
                </div>
            </li>
        </ul>
    </div>

</nav>
<!--Modal Perfil -->
               
 <div class="modal fade" id="modalPerfil" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">Datos de <?php echo $_SESSION['nombreUsu']?></h5>
                 <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                 </button>
             </div>
             <div class="card card-body">
                                <!--Los datos del admin se mostrarán en modo readonly en el apartado de perfil -->
            <form action="" method="" name="formuDatosAdmin">
               <label for="idAdmin">ID</label>
               <input type="number" class="form-control" id="idAdmin" name="idAdmin" value="<?php echo $_SESSION['idUsu']?>" readonly>
<br>
               <label for="nombreAdmin">Nombre</label>
              <input type="text" class="form-control" id="nombreAdmin" name="nombreAdmin" value="<?php echo $_SESSION['nombreUsu']?>" readonly>
<br>
              <label for="emailAdmin">Correo</label>
               <input type="email" class="form-control" id="emailAdmin" name="emailAdmin" value="<?php echo $_SESSION['correoUsu']?>" readonly>
<br>
               <label for="telAdmin">Tel</label>
              <input type="tel" class="form-control" id="telAdmin" name="telAdmin" value="<?php echo $_SESSION['telefonoUsu']?>" readonly>

             
               <br>
               <br>

             </form>
             </div>
                                
         </div>
    </div>
 </div><!--Fin Modal Perfil -->


<div class="d-flex">
    <div class="sidebar sidebar-dark bg-dark">
        <ul class="list-unstyled">
            <li><a href="tareas.php"><i class="fa fa-fw fa-link"></i> Tareas</a></li>
            <li><a href="usuarios.php"><i class="fa fa-fw fa-link"></i> Usuarios</a></li>
            <li><a href="participante.php"><i class="fa fa-fw fa-link"></i> Participante</a></li>
            <li><a href="roles.php"><i class="fa fa-fw fa-link"></i> Roles</a></li>
            <li><a href="areacateg.php"><i class="fa fa-fw fa-link"></i> Area / Categoría</a></li>
            <li><a href="#"><i class="fa fa-fw fa-link"></i> Estados Usuarios</a></li>


        </ul>
    </div>

    <div class="content p-4">
      <h2 class="mb-4">Estados Usuarios</h2>



      	 <!--Modal de Nuevo ESTADO -->
      	<div class="my-3">
        	<button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#nuevoRol" aria-expanded="false" >Nuevo Estado</button>
      	</div>

      <div class="collapse my-3" id="nuevoRol" style="">
                <div class="card card-body">
                    <form name="formuNuevoEstado" method="POST">
                      <div class="form-row">
                          <div class="col-md-2 mb-3">
                              <label for="nombreNuevoEstado">Nombre</label>
                                  <input type="text" class="form-control" id="nombreNuevoEstado" name="nombreNuevoEstado" placeholder="Nombre" value="" required>
    
                          </div>

                      	</div>
                        <div class="form-row">
                            <div class="col-md-2 mb-3">
                                <label for="colorNuevoEstado">Color</label>
                                    <input type="color"  id="colorNuevoEstado" name="colorNuevoEstado" placeholder="Color" value="" required>
      
                            </div>
                          </div>
                     
                      <div class="form-group my-2">
                        <button class="btn btn-primary" type="submit" name="crearNuevoEstado">Crear Estado</button>
                      </div>
                  </form>
                </div>
            </div>







      <div class="card mb-4">
        <div class="card-body">
            <div id="example_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer">
              
              <div class="row">
                      <div class="col-sm-12">
                        <table id="example" class="table table-hover dataTable no-footer dtr-inline" cellspacing="0" width="100%" role="grid" aria-describedby="example_info" style="width: 100%;">
                <thead>
                <tr role="row">
                <th class="sorting_asc" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 85.5px;" aria-sort="ascending" aria-label="Name: activate to sort column descending">Id</th>

                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 120.5px;" aria-label="Position: activate to sort column ascending">Nombre</th>

                <th class="sorting" tabindex="0" aria-controls="example" rowspan="1" colspan="1" style="width: 120.5px;" aria-label="Position: activate to sort column ascending">Color</th>

                
                <th class="actions sorting_disabled" rowspan="1" colspan="1" style="width: 100px;" aria-label="Actions">Acciones</th>
                </tr>
                </thead>


            <tbody>

               <?php
                  #realizamos la consulta en la base de datos para ingresar la informacio'n de las tareas en la tabla. Los JOIN son para poder ingresar los nombres de estados y las categorías.
                    $sqlEstadoUsuario = "  

                      SELECT *
                        FROM estadousu
                          
                    ";

                    $queryEstadoUsuario = mysqli_query($conectar, $sqlEstadoUsuario);

                    while ($rowEstadoUSuario = mysqli_fetch_assoc($queryEstadoUsuario)){
                         
                      ?>
                      <!--Modal Editar Estado -->

                      <div class="modal fade show" id="modalEstadoUsuario<?php echo $rowEstadoUSuario['id_estado'];?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalTArea" style="display: none;" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalEstado"><?php echo $rowEstadoUSuario['nombre_estado'];?></h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <form name="formuActualizaEstado" action="" method="POST">

                                        <div class="modal-body">
		                                   <div class="card mb-4">
		                                      
		                                      <div class="card-body">
		                                          
		                                              <div class="form-group">
		                                                  <label for="idModificarEstado">ID</label>
		                                                  <input type="number" class="form-control" id="idModificarEstado" name="idModificarEstado" aria-describedby="idHelp" placeholder="Id" value="<?php echo $rowEstadoUSuario['id_estado']; ?>" readonly>
		                                                   <br>

		                                                  <label for="nombreModificarEstado">Nombre*</label>
		                                                  <input type="text" class="form-control" id="nombreModificarEstado" name="nombreModificarEstado" aria-describedby="nombreHelp" placeholder="Nombre Estado" value="<?php echo $rowEstadoUSuario['nombre_estado'];?>">
		                                                   <br>
                                                       <label for="colorModificarEstado">Color*</label>
                                                      <input type="color"  id="colorModificarEstado" name="colorModificarEstado" aria-describedby="nombreHelp" placeholder="Color Estado" value="<?php echo $rowEstadoUSuario['color_estado'];?>">
                                                       <br>
		                                              </div>
		                                              
		                                          
		                                      </div>
		                                  </div>
		                                </div>

		                                  <div class="modal-footer">
		                                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
		                                      <button type="submit" class="btn btn-primary" name="modificaEstado">Guardar</button>
		                                  </div>
		                              </form>
                                      

                                
                                </div>

                            </div>
                        </div>
                    </div> <!--Fin modal editar Estado -->


                    <!-- Modal Eliminar Estado -->
                    <div class="modal fade" id="eliminarEstado<?php echo $rowEstadoUSuario['id_estado'];?>" tabindex="-1" role="dialog"  style="display: none;" aria-hidden="true">
                      <div class="modal-dialog modal-dialog-centered" role="document">
                          <div class="modal-content">
                              <div class="modal-header">
                                  <h5 class="modal-title" id="eliminarEstado">Eliminar Estado: <?php echo $rowEstadoUSuario['nombre_estado'];?></h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">×</span>
                                  </button>
                              </div>
                              <div class="modal-body">
                                <form action="" name="formuEliminarEstado" method="POST">

                                  <p>¿Está seguro que desea eliminar al siguiente estado?</p>
                                  <label for="idEstadoEliminar">ID Estado</label>
                                  <input type="number" class="form-control" id="idEstadoEliminar" name="idEstadoEliminar" value="<?php echo $rowEstadoUSuario['id_estado'];?>">
                                  <br>
                                  <label for="nombreEstadoEliminar">Nombre Estado</label>
                                  <input type="text" class="form-control" id="nombreEstadoEliminar" name="nombrEstadoEliminar" value="<?php echo $rowEstadoUSuario['nombre_estado'];?>">
                                  <br>
                                   <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                                     <button  class="btn btn-danger" type="submit" name="modalEliminarEstado">Eliminar</button>
                                   </div>
                                </form>
                                  
                              </div>
                             
                                </div>
                            </div>
                      </div>






                      <?php
                          #se crea una variable para almacenar el valro color y transformarlo en un circulo.
                          $color = '<div style="border-radius:50%; background-color:'.$rowEstadoUSuario['color_estado'].'; width: 20px; height:20px;" data-toggle="tooltip" title="Pendiente"></div>';

                         echo '
                        <tr role="row" class="odd">
                          <td tabindex="0" class="sorting_1">'.$rowEstadoUSuario['id_estado'].'</td>
                          <td>'.$rowEstadoUSuario['nombre_estado'].'</td>
                          <td>'.$color.'</td>
                          <td class=" actions">
                              <a href="#" class="btn btn-icon btn-pill btn-primary" data-toggle="modal" data-target="#modalEstadoUsuario'.$rowEstadoUSuario['id_estado'].'"><i class="fa fa-fw fa-edit"></i></a>


                              <a href="#" class="btn btn-icon btn-pill btn-danger" data-toggle="modal" data-target="#eliminarEstado'.$rowEstadoUSuario['id_estado'].'"><i class="fa fa-fw fa-trash"></i></a>
                          </td>
                        </tr>
                        
                      ';
                    }

                      


                      ?>
                 


              </tbody>
            </table>


              



            <div id="example_processing" class="dataTables_processing card" style="display: none; ">Procesando...</div></div></div><div class="row pt-3" style="border-top: 1px solid rgba(0,0,0,0.2);"><div class="col-sm-12 col-md-5"><div class="dataTables_info" id="example_info" role="status" aria-live="polite" >Mostrando 1 al 25 de <?php echo mysqli_num_rows($queryEstadoUsuario); #cuenta la cantidad de filas de la query ?> entradas</div></div><div class="col-sm-12 col-md-7"><div class="dataTables_paginate paging_simple_numbers" id="example_paginate"><ul class="pagination"><li class="paginate_button page-item previous disabled" id="example_previous"><a href="#" aria-controls="example" data-dt-idx="0" tabindex="0" class="page-link">Anterior</a></li><li class="paginate_button page-item active"><a href="#" aria-controls="example" data-dt-idx="1" tabindex="0" class="page-link">1</a></li><li class="paginate_button page-item "><a href="#" aria-controls="example" data-dt-idx="2" tabindex="0" class="page-link">2</a></li><li class="paginate_button page-item "><a href="#" aria-controls="example" data-dt-idx="3" tabindex="0" class="page-link">3</a></li><li class="paginate_button page-item next" id="example_next"><a href="#" aria-controls="example" data-dt-idx="4" tabindex="0" class="page-link">Siguiente</a></li></ul></div></div></div></div>
        </div>
    



    </div>


     </div>
 </div>


 <script src="js/jquery.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/bootadmin.min.js"></script>
<script src="js/datatables.min.js"></script>
<script src="js/moment.min.js"></script>
<script src="js/fullcalendar.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>

 


        </script>
</body>
</html>