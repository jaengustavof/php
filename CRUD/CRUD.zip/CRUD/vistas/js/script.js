//cuando se ingrese un dato en el formulario email, iniciamos una función y guardamos su valor en una variable llamada email.
$("#email").change(function(){

	//si hay algun cambio en el formulario eliminamos la etiqueta alert.	
	$(".alert").remove();

	var email = $(this).val();

	//creamos una variable de tipo form
	var datos = new FormData();

	//agregamos los datos a la variable. El primer parametro va a ser la variable POST que va a recibir PHP. El valor que le doy a la varialbe POST es lo que almaceno en la variable email declarada arriba.
	datos.append("validarEmail", email);

	$.ajax({
		//primero colocamos el archivo donde vamos a trabajar.
		url:"ajax/formularios.ajax.php",
		//luego se declara el metodo
		method: "POST",
		//informamos los datos que vamos a enviar (los declarados en la variable data de arriba.)
		data: datos,
		cache: false,
		contentType: false,
		processData: false,
		dataType: "json",
		//success es la respuesta que dará si todo sale correctamente.
		success: function(respuesta){
			//si la respuesta es verdadero, quiere decir que existe un email con ese nombre
			if(respuesta){

				$("#email").val(""); //Eliminamos el correo que la persona ingresó

				//si existe un email aparece un mensaje de error. Con parent subimos una etiqueta más arriba y con after ingresamos el código debajo.
				$("#email").parent().after(` 

						<div class="alert alert-warning">

							<b>ERROR:</b>

							El correo ya existe en la BBDD, por favor ingrese otro diferente.

						</div>
					`);
			}
		}

	});

});