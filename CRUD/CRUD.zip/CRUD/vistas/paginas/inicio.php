<?php

#comprobamos si existe una variable de sesión llamada validarIngreso
if(!isset($_SESSION["validarIngreso"])){
	#si no existe lo enviamos a ingreso
	echo '<script>window.location = "ingreso";</script>';#en window.location no es necesario poner la ruta completa ya que lo controlamos desde el archivo .htaccess

		return;#para que no aparezca nada
	
}else{

	#si existe $_SESSION["validarIngreso"], pero es distinta a "ok", emtonces redirigimos al usuario a la página de ingreso
	if($_SESSION["validarIngreso"] != "ok"){

		echo '<script>window.location = "ingreso";</script>';#en window.location no es necesario poner la ruta completa ya que lo controlamos desde el archivo .htaccess

		return;#para que no aparezca nada
	}
 

}

#Creamos un objeto en la vista que haga una petición al controlador. Instanciamos la clase ControladorFormulario y seleccionamos la clase ctrSeleccionarRegistros(). En este caso no necesitamos enviar información en los parámetros, por lo cual se definen como null.
$usuarios = ControladorFormularios::ctrSeleccionarRegistros(null, null);



		

?>

<table class="table table-striped">
	<thead>
		<tr>
			<th>#</th>
			<th>Nombre</th>
			<th>Email</th>
			<th>Fecha</th>
			<th>Acciones</th>
		</tr>
	</thead>
	<tbody>
		<!--Ingresamos los datos que nos responde el controlador-->
		<?php foreach ($usuarios as $key => $value): ?>
			<tr>
				<td><?php echo ($key+1); ?></td><!--coloca el numero de indice-->
				<td><?php echo $value['nombre']; ?></td>
				<td><?php echo $value['email']; ?></td>
				<td><?php echo $value['fecha']; ?></td>
				<td>
					<div class="btn-group">
						<!--para el botón de editar, pasamos los datos via GET. Estos datos son la página a la cual tiene que ir y el id del usuario que debemos editar-->
						<div class="px-1">
							<!--Tanto para editar como para borrar enviamos el token de la BBDD-->
							<a href="index.php?pagina=editar&token=<?php echo $value["token"]; ?>" class="btn btn-warning"><i class="fas fa-pencil-alt"></i></a>
						</div>
						
						
						<form action="" method="POST">
							<!--Tanto para editar como para borrar enviamos el token de la BBDD-->
							<input type="hidden" value="<?php echo $value["token"]; ?>" name="eliminarRegistro">
							<button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>

							<?php
							#el boton eliminar realizar una petición no estática al controlador.
							$eliminar = new ControladorFormularios();
							$eliminar -> ctrEliminarRegistro();

						?>
						</form>
					
											
					</div>
				</td>
			</tr>
			
		<?php endforeach ?>
		

	</tbody>
</table>