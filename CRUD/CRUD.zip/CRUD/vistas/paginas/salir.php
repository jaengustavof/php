<?php

	session_destroy();

	echo '<script>window.location = "ingreso";</script>';#en window.location no es necesario poner la ruta completa ya que lo controlamos desde el archivo .htaccess



?>