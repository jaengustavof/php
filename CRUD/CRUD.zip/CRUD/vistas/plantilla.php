<!--Lleva todo lo que se encuentra en el index.html de la carpeta HTML-->
<?php

#utiliza variable de sesión para que no pueda entrar si no se ha logueado.
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Ejemplo MVC</title>

	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

	<!-- jQuery library -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

	<!-- Popper JS -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

	<!-- Latest compiled JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

	<!--FontAwesome-->
	<script src="https://kit.fontawesome.com/b3275f9798.js" crossorigin="anonymous"></script>
</head>
<body>

	<div class="container-fluid">
		<h3 class="text-center py-3">LOGO</h3>
	</div>

	<div class="container-fluid bg-light">
		<div class="container">
			<ul class="nav nav-justified py-2 nav-pills">

				<?php
				#esta condicion resalta el boton de la secci'on que hemos elegido.

				if(isset($_GET["pagina"])){

					if($_GET["pagina"] == "registro") {

						echo '<li class="nav-item">
								<a h class="nav-link active" href="registro">Registro</a>
							</li>';
					}else {

						echo '<li class="nav-item">
								<a h class="nav-link" href="registro">Registro</a>
							</li>';
					}


					if($_GET["pagina"] == "ingreso") {

						echo '<li class="nav-item">
								<a h class="nav-link active" href="ingreso">Ingreso</a>
							</li>';
					}else {

						echo '<li class="nav-item">
								<a h class="nav-link" href="ingreso">Ingreso</a>
							</li>';
					}



					if($_GET["pagina"] == "inicio") {

						echo '<li class="nav-item">
								<a h class="nav-link active" href="inicio">Inicio</a>
							</li>';
					}else {

						echo '<li class="nav-item">
								<a h class="nav-link" href="inicio">Inicio</a>
							</li>';
					}


					if($_GET["pagina"] == "salir") {

						echo '<li class="nav-item">
								<a h class="nav-link active" href="salir">Salir</a>
							</li>';
					}else {

						echo '<li class="nav-item">
								<a h class="nav-link" href="salir">Salir</a>
							</li>';
					}

				}else {
					#GET: $_GET["variable"] Varialbes que se pasan como parametro via URL (tambien conocido como cadena de consulta a traves de la URL)
					#La primer variable se separa con ?
					#las que siguen a continuacion se separan con &
		
					#al href le indicamos la ruta con GET y el valor de la pagina = al nombre del archivo en la carpeta paginas
					echo'<li class="nav-item">
							<a h class="nav-link active" href="registro">Registro</a>
						</li>
						<li class="nav-item">
							<a h class="nav-link" href="ingreso">Ingreso</a>
						</li>
						<li class="nav-item">
							<a  class="nav-link" href="inicio">Inicio</a>
						</li>
						<li class="nav-item">
							<a class="nav-link" href="salir">Salir</a>
						</li>';
				}

				?>

			
				
			</ul>
		</div>
	</div>


	<div class="container-fluid">
		<div class="container py-5">
			

			<?php

				#isset(): Determina si una variable est'a definida y no es null.
				#controlamos que llegue una variable por GET.
				if(isset($_GET["pagina"])){

					if($_GET["pagina"] == "registro" || $_GET["pagina"] == "ingreso" || $_GET["pagina"] == "inicio" || $_GET["pagina"] == "editar" || $_GET["pagina"] == "salir") {

						#en caso de reconocar cualquiera de esas variables GET, abriria la pagina correspondiente al valor de la variable GET.
						include "paginas/".$_GET["pagina"].".php";
					}else{
						#si quieren forzar el valor de la variable GET, redirige a un error 404.
						include "paginas/error404.php";
					}

				}else{
					#si no se envia una variable, se incluye la pagina de registro del sistema.
					include "paginas/registro.php";

				}

				




			?>

		</div>
	</div>

<script src="vistas/js/script.js"></script>
	
</body>
</html>