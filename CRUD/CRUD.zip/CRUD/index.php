<?php	

#Aqui se muestran la salida de las vistas al usuario y tambien a traves de el enviaremos las distintas acciones que el usuario envia el controlador.

#require() establece que el codigo del archivo invocado es requerido, es decir, obligatorio para el funcionamiento del programa. Por ello, si el archivo especificado en la funcion require() no se encuentra,  saltará un error "PHP Fatal error" y el programa PHP se detendrá.


require_once "controladores/plantilla.controlador.php";

require_once "controladores/formularios.controlador.php";

require_once "modelos/formularios.modelo.php";


$plantilla = new ControladorPlantilla();
#creamos el objeto invocando a la clase del archivo plantilla.controlador.php


$plantilla -> ctrTraerPlantilla();
#ejecutamos el m'etodo que se encuentra dentro de la clase.




#no se cierra la etiqueta PHP para evitar ataques cross-site