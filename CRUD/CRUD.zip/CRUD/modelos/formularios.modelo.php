<?php

#solicitamos la conexion a la bbdd
require_once "conexion.php";

class ModeloFormularios{

	/*=============================================
	= Registro - El modelo responde al controlador =
	=============================================*/

	#los parametros necesarios para este modelo son el nombre de la tabla y los datos que quiero almacenar. Se envian desde el formularios.controlador.php
	static public function mdlRegistro($tabla, $datos){

		#objeto de conexion de bbdd. traemos el objeto link de la conexion de la bbdd. archivo conexion.php. Este objet prepara la sentencia SQL que se enviará a la bbdd para crear un nuevo registro.
		$stmt = Conexion::conectar()->prepare("INSERT INTO $tabla(token, nombre, email, password) VALUES (:token, :nombre, :email, :password)"); #se agreda :a los valores para que sean parametros ocultos.

		#para enlazar los parametros que vienen en $datos con los valores ocultos que enviamos, necesitamos la funcion bindParam(). bindParam()vincula una variable de PHP a un parámetro de sustitución con nombre o de signo de interrogación correspondiente de la sentencia SQL que fue usado para preparar la sentencia.

		#lleva 4 parametros. El nombre del valor ocultao, el valor que enviamos por el array y el tipo de dato que enviamos(ej. string).
		$stmt->bindParam(":token", $datos["token"], PDO::PARAM_STR);
		$stmt->bindParam(":nombre", $datos["nombre"], PDO::PARAM_STR);
		$stmt->bindParam(":email", $datos["email"], PDO::PARAM_STR);
		$stmt->bindParam(":password", $datos["password"], PDO::PARAM_STR);

		#preguntamos si el objeto $stmt se está ejecutando.
		if($stmt->execute()){

			return "ok";

		}else{

			print_r(Conexion::conectar()->errorInfo());

		}

		#cerramos la conexión
		$stmt ->close();
		#vaciamos el objeto. Esto se hace por seguridad.
		$stmt = null;


	}


	/*=============================================
	= Seleccionamos Registros (READ) - El modelo responde al controlador               						=
	=============================================*/

	static public function mdlSeleccionarRegistros($tabla, $item, $valor){

		#con esta condición sabremos si lo que se quiere es leer los registros (ya que se pasará solo un parámetro y los otros como null). O si se quiere loguear (se pasarán los 3 parámetros con sus valores.)
		if($item == null && $valor == null) {
			#DATE_FORMAT modifica el formato de la fecha. En este caso lo solicitamos como dia / mes / año.
			$stmt = Conexion::conectar()->prepare("SELECT *,DATE_FORMAT(fecha, '%d/%m/%Y') AS fecha FROM $tabla ORDER BY id DESC");
			#el statement traer'a todos los valores de la tabla traida en el parametro de mdlSeleccionarRegistro. Esta tabla es asignada en formularios.controlador.php linea 46.

			$stmt->execute(); #ejecutamos la declaración

			return $stmt ->fetchAll(); #fetchAll() devuelve todos los registros. Devolvemos una respuesta con todos los registros.

			
		}else{

			$stmt = Conexion::conectar()->prepare("SELECT *,DATE_FORMAT(fecha, '%d/%m/%Y') AS fecha FROM $tabla WHERE $item = :$item ORDER BY id DESC");
			

			#concatenamos el valor de $item al bindParam. y como dato pasamos el $valor de la variable POST.
			$stmt->bindParam(":".$item, $valor, PDO::PARAM_STR);
			$stmt->execute(); 

			#si encuentra una coincidencia devuelve un fetch()
			return $stmt ->fetch(); 

		}


		#cerramos la conexión
		$stmt ->close();
		#vaciamos el objeto. Esto se hace por seguridad.
		$stmt = null;


	}

	/*=============================================
	Actualizar Registro
	=============================================*/
	#los parametros necesarios para este modelo son el nombre de la tabla y los datos que quiero almacenar. Se envian desde el formularios.controlador.php
	static public function mdlActualizarRegistro($tabla, $datos){
	
	#objeto de conexion de bbdd. traemos el objeto link de la conexion de la bbdd. archivo conexion.php. Este objet prepara la sentencia SQL que se enviará a la bbdd para crear un nuevo registro.
		$stmt = Conexion::conectar()->prepare("UPDATE $tabla SET token=:nuevoToken, nombre=:nombre, email=:email, password=:password WHERE token = :token");#se actualizan :a los valores para que sean parametros ocultos.

		$stmt->bindParam(":nombre", $datos["nombre"], PDO::PARAM_STR);
		$stmt->bindParam(":email", $datos["email"], PDO::PARAM_STR);
		$stmt->bindParam(":password", $datos["password"], PDO::PARAM_STR);
		$stmt->bindParam(":nuevoToken", $datos["nuevoToken"], PDO::PARAM_STR);
		$stmt->bindParam(":token", $datos["token"], PDO::PARAM_STR);

		if($stmt->execute()){

			return "ok";

		}else{

			print_r(Conexion::conectar()->errorInfo());

		}

		$stmt->close();

		$stmt = null;	

	}



	/*=============================================
	Eliminar Registro
	=============================================*/


	static public function mdlEliminarRegistro($tabla, $valor){
	
	#objeto de conexion de bbdd. traemos el objeto link de la conexion de la bbdd. archivo conexion.php. Este objet prepara la sentencia SQL que se enviará a la bbdd para crear un nuevo registro.
		$stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE token = :token");#se actualizan :a los valores para que sean parametros ocultos.

		$stmt->bindParam(":token", $valor, PDO::PARAM_INT);

		if($stmt->execute()){

			return "ok";

		}else{

			print_r(Conexion::conectar()->errorInfo());

		}

		$stmt->close();

		$stmt = null;	

	}# fin Eliminar Registro


	/*=============================================
	Actualizar Intentos Fallidos de ingreso
	=============================================*/
	#los parametros necesarios para este modelo son el nombre de la tabla y los datos que quiero almacenar. Se envian desde el formularios.controlador.php
	static public function mdlActualizarIntentosFallidos($tabla, $valor, $token){
	
	#objeto de conexion de bbdd. traemos el objeto link de la conexion de la bbdd. archivo conexion.php. Este objet prepara la sentencia SQL que se enviará a la bbdd para crear un nuevo registro.
		$stmt = Conexion::conectar()->prepare("UPDATE $tabla SET intentos_fallidos=:intentos_fallidos WHERE token = :token");#se actualizan :a los valores para que sean parametros ocultos.

		$stmt->bindParam(":intentos_fallidos", $valor, PDO::PARAM_INT);
		$stmt->bindParam(":token", $token, PDO::PARAM_STR);

		if($stmt->execute()){

			return "ok";

		}else{

			print_r(Conexion::conectar()->errorInfo());

		}

		$stmt->close();

		$stmt = null;	

	}


}

?>