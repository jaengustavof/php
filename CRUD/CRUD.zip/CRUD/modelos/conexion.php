<?php

#crea la conexion al servidor
class Conexion {

	static public function conectar(){

		#PDO("nombre del servidor; nombre de BBDD", "nombre de usuario", "contraseña");

		$link = new PDO("mysql:host=localhost;dbname=crud-pcp", 
			"root", 
			"");

		#ejecuta con la codificacion utf8
		$link->exec("set names utf8");

		return $link;


	}
}

?>