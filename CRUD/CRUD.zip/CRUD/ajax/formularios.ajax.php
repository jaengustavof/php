<?php



require_once "../controladores/formularios.controlador.php";
require_once "../modelos/formularios.modelo.php";

/*=====================================
=            Clase de Ajax            =
=====================================*/

class AjaxFormularios {

	/*=====================================
	=    VALIDAR MAIL EXISTENTE           =
	=====================================*/
	public $validarEmail; #propiedad publica

	public function ajaxValidarEmail(){

		$item = "email";
		$valor = $this->validarEmail; #le asignamos el valor de la propiedad publica. Esta propiedad publica obtiene su valor con el objeto de AJAX cuando recibe la variable POST. VER MAS ABAJO

		#utilizamos el metodo de registro para poder solicitar informacion a la bbdd
		$respuesta = ControladorFormularios::ctrSeleccionarRegistros($item, $valor);
		echo json_encode($respuesta);
	}


}

/*=============================================
= Objeto de AJAX que recibe la variable POST =
===============================================*/

#consultamos si se envía una varible POST llamada validarEmail. Esta variable es declarada en el archivo sript.js.
if(isset($_POST["validarEmail"])){

	$valEmail = new AjaxFormularios();
	$valEmail -> validarEmail = $_POST["validarEmail"]; #asignamos valor a la propiedad publica declarada arriba.
	$valEmail -> ajaxValidarEmail();

}


