<?php

# LA CONEXION A FORMULARIO.MODELO SE REQUIERE EN EL INDEX.
class ControladorFormularios{

	/*=============================================
	= Registro - Recibe la respuesta del modelo (formularios.modelos.php) y envia una respuesta a la vista (registro.php)                       =
	=============================================*/
	#metodo que recibirá las variables POST que se enviar'an por el formualrio.
	
	static public function ctrRegistro(){

		if(isset($_POST["registroNombre"])){

			#Antes de enviar toda la información a la base de datos controlamos el tipo de información que ha ingresado el usuario.

			#preg_match controla los caracteres que ingrean en el formulario. Primero si ingresan las expresiones regulares dentro de /^[]+$/. Dentro de los corchetes se ponen los carcteres que vamos a permitir. Luego de la coma aclaramos a qué aplicaremos las expresiones regulares ($_POST["registroNombre"] - $_POST["registroEmail"]) -$_POST["registroPassword"])).

			if(preg_match('/^[a-zA-ZñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["registroNombre"]) && preg_match('/^[^0-9][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[@][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{2,4}$/', $_POST["registroEmail"]) && preg_match('/^[0-9a-zA-Z]+$/', $_POST["registroPassword"])){

				#creamos la variable tabla con el nombre de la tabla de la bbdd a la que llevaremos la info.
				$tabla = "registros";


				#encriptamos su nombre y su correo generando un token. md5() es la funcion de php para encriptar información
				$token = md5($_POST["registroNombre"]."+".$_POST["registroEmail"]);

				#encriptamos la contraseña. dentro del crypt va lo que ingresa el usuario, seguido del metodo de encriptación que utilizaresmos. En este caso metodo BLOWFISH (https://www.php.net/manual/es/function.crypt.php).
				$encriptarPassword = crypt($_POST["registroPassword"], '$2a$07$usesomesillystringforsalt$');

				#la información la enviamos en un array. Nos llevamos el nombre, el mail y la contraseña. El id y la fecha son automáticos.
				$datos = array("token" =>$token, 
							   "nombre" =>$_POST["registroNombre"],
							   "email" => $_POST["registroEmail"], 
							   "password" => $encriptarPassword);

				#enviamos la respuesta a traves de una función instanciando la clase ModelFormularios::mdelRegistro() que se encuentra en el archivo formularios.modelo.php
				$respuesta = ModeloFormularios::mdlRegistro($tabla, $datos); #esto responde un "ok" o dar'a una explicaci'on del error. formularios.modelos.php

				return $respuesta;
				#esta respuesta la espera el archivo vistas/paginas/registro.php, línea 51.
			}else{

				$respuesta = "error";
				return $respuesta;
				#esta respuesta la espera el archivo vistas/paginas/registro.php, línea 51.
			}

		}



	}# fin ctrRegistro()



	/*=============================================
	= Seleccionamos Registros (READ)              =
	=============================================*/
	
	static public function ctrSeleccionarRegistros($item, $valor){
		#creamos el objeto que enviaremos al modelo, con el nombre de la tabla que necesitamos consultar.
		$tabla = "registros";

		#solicitamos una respuesta al modelo. Se pasan tres parametros ya que se reutiliza el mismo m'etodo para ingreso. En este caso no necesitamos comparar la información de una columna con un valor, por lo que enviamos los últimos dos parámetros como null.
		$respuesta = ModeloFormularios::mdlSeleccionarRegistros($tabla, $item, $valor);

		return $respuesta; #esta respuesta se devuelve a la vista inicio.php.

	}


	/*=============================================
	= Ingreso - Login                             =
	=============================================*/

	public function ctrIngreso(){

		if(isset($_POST["ingresoEmail"])){

		#solicitamos una respuesta al modelo. Pero esta vez le pasamos más parametros. además de la tabla, pasamos el nombre de columna donde vamos a buscar la similitud de los datos enviados por POST($item). El tercer parámetro será el valor que quiero encontrar coincidencia.

		$tabla = "registros";
		$item = "email";
		$valor = $_POST["ingresoEmail"];
		#encriptamos el password del mismo modo que en el registro par poder comparar con la información que 
		$encriptarPassword = crypt($_POST["ingresoPassword"], '$2a$07$usesomesillystringforsalt$');


		$respuesta = ModeloFormularios::mdlSeleccionarRegistros($tabla, $item, $valor);

		#si recibimos respuesta del modelo, confirmamos que el email de la respuesta corresponda con la variable $_POST["ingresoEmail"] y la contraseña de la resuesta corresponda con la variable $_POST["ingresoPassword"].
		if($respuesta == false){#dara false si no encuentra a ningun email identico al que ingresa el usuario

				echo '<script>

			if(window.history.replaceState){
				window.history.replaceState(null, null, window.location.href);
			}

			</script>';

			echo '<div class="alert alert-danger">Error al ingresar al sistema, el email o la contraseña no coinciden.</div>';

			}elseif($respuesta["email"] == $_POST["ingresoEmail"] && $respuesta["password"] == $encriptarPassword){

			#Si el email y la contraseña coinciden, actualizamos la columna de intentos fallidos a 0.
			ModeloFormularios::mdlActualizarIntentosFallidos($tabla, 0, $respuesta["token"]);

			$_SESSION["validarIngreso"] = "ok";

				echo '<script>

					if ( window.history.replaceState ) {

						window.history.replaceState( null, null, window.location.href );

					}

					window.location = "inicio"; 

				</script>';#en window.location no es necesario poner la ruta completa ya que lo controlamos desde el archivo .htaccess

	
			}elseif($respuesta["email"] == $_POST["ingresoEmail"] && $respuesta["password"] != $_POST["ingresoPassword"]){
				#si la contraseña no es correcta, comenzamos a aumentar la variable de intentos_fallidos.

				#no permitimos mas de tres intentos fallidos

				if($respuesta["intentos_fallidos"] < 3){

					$tabla = "registros";
					$intentos_fallidos = $respuesta["intentos_fallidos"]+1;

					#enviamos los parametros al modelo. La variable $tabla ya está declarada al principio. Y la variable $intentos_fallidos la declaramos arriba. Finalmente enviamos el token para saber a que usuario debemos incrementar
					ModeloFormularios::mdlActualizarIntentosFallidos($tabla, $intentos_fallidos, $respuesta["token"]);

				}else{

					echo '<div class="alert alert-warning">RECAPCHA Debes validar que no eres un robot</div>';
				}
				

				echo '<script>

					if(window.history.replaceState){
						window.history.replaceState(null, null, window.location.href);
					}

					</script>';

				echo '<div class="alert alert-danger">Error al ingresar al sistema, email o contraseña no coinciden</div>';
			}
		

		}

	}#fin ctrIngreso()



/*=============================================
	Actualizar Registro
	=============================================*/
	static public function ctrActualizarRegistro(){
		#preguntamo si hay una variable POST para actualizar el nombre.
		if(isset($_POST["actualizarNombre"])){

			if(preg_match('/^[a-zA-ZñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["actualizarNombre"]) && preg_match('/^[^0-9][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[@][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{2,4}$/', $_POST["actualizarEmail"])){

				#traemos información desde la BBDD.
				$usuario = ModeloFormularios::mdlSeleccionarRegistros("registros", "token", $_POST["tokenUsuario"]);

				#asignamos el valor del nombre y el mail que traemos de la base de datos y lo comparamos con el token que ya existe.
				$compararToken = md5($usuario["nombre"]."+".$usuario["email"]);

				#si el POST es igual a la variable $compararToken procedemos a actualizar el registro.
				if($compararToken == $_POST["tokenUsuario"]){


					#una vez confirmado preguntamos si ha cambiado la contraseña o la ha dejado igual
					if($_POST["actualizarPassword"] != ""){		

						if (preg_match('/^[0-9a-zA-Z]+$/', $_POST["actualizarPassword"])) {
							
							$password = crypt($_POST["actualizarPassword"], '$2a$07$usesomesillystringforsalt$');


							
						}					

					}else{

						$password = $_POST["passwordActual"];
					}
					#creamos la variable tabla con el nombre de la tabla de la bbdd a la que llevaremos la info.
					$tabla = "registros";

					#la información la enviamos en un array. Nos llevamos el nombre, el mail y la contraseña. El id y la fecha son automáticos.
					$datos = array("token" => $_POST["tokenUsuario"],
									"nuevoToken" => md5($_POST["actualizarNombre"]."+".$_POST["actualizarEmail"]),
									"nombre" => $_POST["actualizarNombre"],
						           "email" => $_POST["actualizarEmail"],
						           "password" => $password);
					
					#enviamos la respuesta a traves de una función instanciando la clase ModelFormularios::mdlActualizarRegistro() que se encuentra en el archivo formularios.modelo.php
					$respuesta = ModeloFormularios::mdlActualizarRegistro($tabla, $datos);#esto responde un "ok" o dar'a una explicaci'on del error. formularios.modelos.php

					return $respuesta;

				}else{


					$respuesta = "error";
					return $respuesta;

				}



			}else{


				$respuesta = "error";
				return $respuesta;

				}

			

			

		}


	}#fin ctrActualizarRegistro()


	/*=============================================
	Eliminar Registro
	=============================================*/


	public function ctrEliminarRegistro(){

		if(isset($_POST["eliminarRegistro"])){

			#traemos información desde la BBDD.
			$usuario = ModeloFormularios::mdlSeleccionarRegistros("registros", "token", $_POST["eliminarRegistro"]);

			#asignamos el valor del nombre y el mail que traemos de la base de datos y lo comparamos con el token que ya existe.
			$compararToken = md5($usuario["nombre"]."+".$usuario["email"]);

			#si el POST es igual a la variable $compararToken procedemos a actualizar el registro.
			if($compararToken == $_POST["eliminarRegistro"]){

				$tabla = "registros";
				$valor = $_POST["eliminarRegistro"];

				$respuesta = ModeloFormularios::mdlEliminarRegistro($tabla, $valor);#esto responde un "ok" o dar'a una explicaci'on del error. formularios.modelos.php

				if($respuesta == "ok"){

					echo '<script>

					if(window.history.replaceState){
						window.history.replaceState(null, null, window.location.href);
					}

					window.location = "inicio";

					</script>';#en window.location no es necesario poner la ruta completa ya que lo controlamos desde el archivo .htaccess

				}

			}

			

		}



	}



}






?>