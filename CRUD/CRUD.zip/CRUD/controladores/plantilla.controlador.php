<?php
#es el controlador que permitirá que la plantilla.php se muestre ne index.php

Class ControladorPlantilla {

	/*==========================
	LLAMADA A LA PLANTILLA.PHP
	===========================*/

	#m'etodo publico del controlador que traerá la plantilla.
	public function ctrTraerPlantilla(){

		#include() Se utiliza para invocar el archivo que contiene codigo html-php.
		include "vistas/plantilla.php";

	}


}





?>